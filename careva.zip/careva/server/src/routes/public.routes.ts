import { Router } from 'express';
import * as evaluationController from '../controllers/evaluation.controller.js';

const router = Router();

// Public credential verification — no auth required
router.get('/verify/:credentialId', evaluationController.publicVerify);

export default router;
