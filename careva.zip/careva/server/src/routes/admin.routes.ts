import { Router } from 'express';
import * as adminController from '../controllers/admin.controller.js';
import { authenticate, authorize } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authenticate, authorize('ADMIN'));

router.get('/stats', adminController.getStats);
router.get('/analytics', adminController.getAnalytics);
router.get('/users', adminController.getUsers);
router.get('/submissions', adminController.getSubmissions);
router.get('/jobs', adminController.getJobs);
router.get('/skills', adminController.getSkills);
router.put('/skills/:id', adminController.toggleSkill);

export default router;
