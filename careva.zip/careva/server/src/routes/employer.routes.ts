import { Router } from 'express';
import * as employerController from '../controllers/employer.controller.js';
import { authenticate, authorize } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authenticate, authorize('EMPLOYER'));

router.get('/profile', employerController.getProfile);
router.put('/profile', employerController.updateProfile);
router.get('/dashboard', employerController.getDashboard);

router.get('/jobs', employerController.getJobs);
router.post('/jobs', employerController.createJob);
router.get('/jobs/:id', employerController.getJob);
router.put('/jobs/:id', employerController.updateJob);

router.get('/candidates', employerController.searchCandidates);
router.get('/candidates/:studentId', employerController.getCandidate);

router.get('/applications', employerController.getApplications);
router.put('/applications/:id', employerController.updateApplication);

router.get('/shortlist', employerController.getShortlist);
router.post('/shortlist', employerController.shortlist);

router.get('/skills/catalog', employerController.getSkillsCatalog);

export default router;
