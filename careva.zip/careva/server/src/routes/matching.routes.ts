import { Router } from 'express';
import * as matchingController from '../controllers/matching.controller.js';
import { authenticate, authorize } from '../middleware/auth.middleware.js';

const router = Router();

// Student endpoints
router.get(
  '/jobs',
  authenticate,
  authorize('STUDENT'),
  matchingController.matchStudentJobs
);
router.post(
  '/apply',
  authenticate,
  authorize('STUDENT'),
  matchingController.applyToJob
);
router.get(
  '/applications',
  authenticate,
  authorize('STUDENT'),
  matchingController.getMyApplications
);
router.get(
  '/insights',
  authenticate,
  authorize('STUDENT'),
  matchingController.getCareerInsights
);

// Employer endpoints
router.post(
  '/job/:jobId/run',
  authenticate,
  authorize('EMPLOYER'),
  matchingController.matchJobCandidates
);

// Shared detail
router.get(
  '/detail/:jobId/:studentId',
  authenticate,
  matchingController.getMatchDetail
);

export default router;
