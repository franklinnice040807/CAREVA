import { Router } from 'express';
import * as evaluationController from '../controllers/evaluation.controller.js';
import { authenticate, authorize } from '../middleware/auth.middleware.js';

const router = Router();

// Student evaluation endpoints
router.post(
  '/run',
  authenticate,
  authorize('STUDENT'),
  evaluationController.runEvaluation
);

router.get(
  '/submission/:submissionId',
  authenticate,
  authorize('STUDENT'),
  evaluationController.getSubmissionEvaluation
);

router.get('/rubric', authenticate, evaluationController.getRubric);

export default router;
