import { Router } from 'express';
import * as studentController from '../controllers/student.controller.js';
import { authenticate, authorize } from '../middleware/auth.middleware.js';
import { upload } from '../middleware/upload.middleware.js';

const router = Router();

router.use(authenticate, authorize('STUDENT'));

router.get('/profile', studentController.getProfile);
router.put('/profile', studentController.updateProfile);
router.get('/dashboard', studentController.getDashboard);

router.get('/skills/catalog', studentController.getSkillsCatalog);
router.post('/skills', studentController.addSkill);
router.delete('/skills/:id', studentController.removeSkill);

router.post('/certificates', studentController.addCertificate);
router.delete('/certificates/:id', studentController.deleteCertificate);

router.post('/projects', studentController.addProject);
router.delete('/projects/:id', studentController.deleteProject);

router.get('/submissions', studentController.getSubmissions);
router.post('/submissions', upload.single('media'), studentController.createSubmission);

router.get('/passport', studentController.getPassport);

export default router;
