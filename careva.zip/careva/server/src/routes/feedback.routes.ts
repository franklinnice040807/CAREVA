import { Router } from 'express';
import * as feedbackController from '../controllers/feedback.controller.js';
import { authenticate, authorize } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authenticate, authorize('EMPLOYER'));
router.post('/', feedbackController.submit);
router.get('/', feedbackController.list);
router.get('/pending', feedbackController.pendingHires);

export default router;
