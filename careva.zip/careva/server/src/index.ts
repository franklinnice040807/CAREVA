import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

import authRoutes from './routes/auth.routes.js';
import studentRoutes from './routes/student.routes.js';
import evaluationRoutes from './routes/evaluation.routes.js';
import publicRoutes from './routes/public.routes.js';
import employerRoutes from './routes/employer.routes.js';
import matchingRoutes from './routes/matching.routes.js';
import notificationRoutes from './routes/notification.routes.js';
import feedbackRoutes from './routes/feedback.routes.js';
import adminRoutes from './routes/admin.routes.js';
import { errorHandler, notFoundHandler } from './middleware/error.middleware.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(
  cors({
    origin: process.env.CLIENT_URL || 'http://localhost:5173',
    credentials: true,
  })
);

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  message: { success: false, message: 'Too many requests, please try again later' },
});
app.use('/api/', limiter);

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    message: 'CAREVA API is running',
    version: '1.0.0',
    aiProvider: process.env.AI_PROVIDER || 'demo',
    timestamp: new Date().toISOString(),
  });
});

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/students', studentRoutes);
app.use('/api/v1/evaluations', evaluationRoutes);
app.use('/api/v1/public', publicRoutes);
app.use('/api/v1/employers', employerRoutes);
app.use('/api/v1/matching', matchingRoutes);
app.use('/api/v1/notifications', notificationRoutes);
app.use('/api/v1/feedback', feedbackRoutes);
app.use('/api/v1/admin', adminRoutes);




app.use(notFoundHandler);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`\n🚀 CAREVA API running on http://localhost:${PORT}`);
  console.log(`   Health:      http://localhost:${PORT}/api/health`);
  console.log(`   Auth:        /api/v1/auth`);
  console.log(`   Students:    /api/v1/students`);
  console.log(`   Evaluations: /api/v1/evaluations`);
  console.log(`   Public:      /api/v1/public/verify/:credentialId`);
  console.log(`   Employers:   /api/v1/employers`);
  console.log(`   Matching:    /api/v1/matching`);
  console.log(`   Notifications:/api/v1/notifications`);
  console.log(`   Feedback:    /api/v1/feedback`);
  console.log(`   Admin:       /api/v1/admin`);
  console.log(`   AI Provider: ${process.env.AI_PROVIDER || 'demo'}\n`);
});

export default app;
