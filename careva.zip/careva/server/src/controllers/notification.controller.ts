import { Response } from 'express';
import { AuthRequest } from '../middleware/auth.middleware.js';
import * as notificationService from '../services/notification.service.js';

export async function list(req: AuthRequest, res: Response) {
  const unreadOnly = req.query.unread === 'true';
  const notifications = await notificationService.getNotifications(req.user!.id, unreadOnly);
  const unreadCount = await notificationService.getUnreadCount(req.user!.id);
  res.json({ success: true, data: { notifications, unreadCount } });
}

export async function markRead(req: AuthRequest, res: Response) {
  try {
    await notificationService.markAsRead(req.user!.id, req.params.id);
    res.json({ success: true, message: 'Marked as read' });
  } catch (err: any) {
    return res.status(404).json({ success: false, message: err.message });
  }
}

export async function markAllRead(req: AuthRequest, res: Response) {
  await notificationService.markAllAsRead(req.user!.id);
  res.json({ success: true, message: 'All marked as read' });
}
