import { Response } from 'express';
import { z } from 'zod';
import { CompetencyLevel, EmploymentType, ApplicationStatus } from '@prisma/client';
import { AuthRequest } from '../middleware/auth.middleware.js';
import * as employerService from '../services/employer.service.js';

const profileSchema = z.object({
  companyName: z.string().min(2).optional(),
  industry: z.string().optional(),
  location: z.string().optional(),
  website: z.string().optional(),
  description: z.string().max(3000).optional(),
  companySize: z.string().optional(),
  contactInfo: z.string().optional(),
  logo: z.string().optional(),
});

const jobSchema = z.object({
  title: z.string().min(3),
  description: z.string().min(20),
  trade: z.string().min(1),
  location: z.string().optional(),
  salaryRange: z.string().optional(),
  employmentType: z.nativeEnum(EmploymentType).optional(),
  requiredCompetency: z.nativeEnum(CompetencyLevel).optional(),
  experienceRequired: z.number().min(0).optional(),
  requirements: z
    .array(
      z.object({
        skillId: z.string(),
        requiredLevel: z.nativeEnum(CompetencyLevel).optional(),
      })
    )
    .min(1, 'At least one required skill'),
});

const jobUpdateSchema = z.object({
  title: z.string().min(3).optional(),
  description: z.string().min(20).optional(),
  trade: z.string().optional(),
  location: z.string().optional(),
  salaryRange: z.string().optional(),
  employmentType: z.nativeEnum(EmploymentType).optional(),
  requiredCompetency: z.nativeEnum(CompetencyLevel).optional(),
  experienceRequired: z.number().min(0).optional(),
  isActive: z.boolean().optional(),
});

export async function getProfile(req: AuthRequest, res: Response) {
  const profile = await employerService.getEmployerProfile(req.user!.id);
  if (!profile) return res.status(404).json({ success: false, message: 'Profile not found' });
  res.json({ success: true, data: profile });
}

export async function updateProfile(req: AuthRequest, res: Response) {
  const data = profileSchema.parse(req.body);
  const profile = await employerService.updateEmployerProfile(req.user!.id, data);
  res.json({ success: true, message: 'Profile updated', data: profile });
}

export async function getDashboard(req: AuthRequest, res: Response) {
  const stats = await employerService.getDashboardStats(req.user!.id);
  res.json({ success: true, data: stats });
}

export async function createJob(req: AuthRequest, res: Response) {
  const data = jobSchema.parse(req.body);
  const job = await employerService.createJob(req.user!.id, data);
  res.status(201).json({ success: true, message: 'Job created', data: job });
}

export async function updateJob(req: AuthRequest, res: Response) {
  const data = jobUpdateSchema.parse(req.body);
  try {
    const job = await employerService.updateJob(req.user!.id, req.params.id, data);
    res.json({ success: true, message: 'Job updated', data: job });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function getJobs(req: AuthRequest, res: Response) {
  const jobs = await employerService.getJobs(req.user!.id);
  res.json({ success: true, data: jobs });
}

export async function getJob(req: AuthRequest, res: Response) {
  try {
    const job = await employerService.getJobById(req.user!.id, req.params.id);
    res.json({ success: true, data: job });
  } catch (err: any) {
    return res.status(404).json({ success: false, message: err.message });
  }
}

export async function searchCandidates(req: AuthRequest, res: Response) {
  const filters = {
    trade: req.query.trade as string | undefined,
    skillId: req.query.skillId as string | undefined,
    competency: req.query.competency as CompetencyLevel | undefined,
    location: req.query.location as string | undefined,
    minExperience: req.query.minExperience ? Number(req.query.minExperience) : undefined,
    sort: (req.query.sort as 'match' | 'score' | 'experience' | 'recent') || 'match',
    jobId: req.query.jobId as string | undefined,
  };
  const candidates = await employerService.searchCandidates(req.user!.id, filters);
  res.json({ success: true, data: candidates });
}

export async function getCandidate(req: AuthRequest, res: Response) {
  try {
    const candidate = await employerService.getCandidatePassport(req.user!.id, req.params.studentId);
    res.json({ success: true, data: candidate });
  } catch (err: any) {
    return res.status(404).json({ success: false, message: err.message });
  }
}

export async function getApplications(req: AuthRequest, res: Response) {
  const jobId = req.query.jobId as string | undefined;
  const apps = await employerService.getApplications(req.user!.id, jobId);
  res.json({ success: true, data: apps });
}

export async function updateApplication(req: AuthRequest, res: Response) {
  const schema = z.object({
    status: z.nativeEnum(ApplicationStatus),
    notes: z.string().optional(),
  });
  const data = schema.parse(req.body);
  try {
    const app = await employerService.updateApplicationStatus(
      req.user!.id,
      req.params.id,
      data.status,
      data.notes
    );
    res.json({ success: true, message: 'Application updated', data: app });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function shortlist(req: AuthRequest, res: Response) {
  const schema = z.object({
    studentId: z.string(),
    jobId: z.string().optional(),
    notes: z.string().optional(),
  });
  const data = schema.parse(req.body);
  const item = await employerService.shortlistCandidate(
    req.user!.id,
    data.studentId,
    data.jobId,
    data.notes
  );
  res.status(201).json({ success: true, message: 'Candidate shortlisted', data: item });
}

export async function getShortlist(req: AuthRequest, res: Response) {
  const list = await employerService.getShortlist(req.user!.id);
  res.json({ success: true, data: list });
}

export async function getSkillsCatalog(req: AuthRequest, res: Response) {
  const trade = req.query.trade as string | undefined;
  const skills = await employerService.getSkillsCatalog(trade);
  res.json({ success: true, data: skills });
}
