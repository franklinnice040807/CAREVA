import { Response } from 'express';
import { z } from 'zod';
import { CompetencyLevel } from '@prisma/client';
import { AuthRequest } from '../middleware/auth.middleware.js';
import * as studentService from '../services/student.service.js';

const profileUpdateSchema = z.object({
  fullName: z.string().min(2).optional(),
  phone: z.string().optional(),
  location: z.string().optional(),
  institute: z.string().optional(),
  course: z.string().optional(),
  trade: z.string().optional(),
  graduationYear: z.number().int().min(1990).max(2035).optional().nullable(),
  about: z.string().max(2000).optional(),
  experienceYears: z.number().min(0).max(50).optional(),
  profileImage: z.string().optional(),
});

const addSkillSchema = z.object({
  skillId: z.string().min(1),
  selfAssessedLevel: z.nativeEnum(CompetencyLevel).optional(),
  experienceNotes: z.string().max(1000).optional(),
});

const certSchema = z.object({
  title: z.string().min(2),
  issuer: z.string().optional(),
  issueDate: z.string().optional(),
  fileUrl: z.string().optional(),
});

const projectSchema = z.object({
  title: z.string().min(2),
  description: z.string().optional(),
  skillsUsed: z.array(z.string()).optional(),
  url: z.string().url().optional().or(z.literal('')),
});

const submissionSchema = z.object({
  skillId: z.string().min(1),
  title: z.string().min(3),
  description: z.string().min(10),
  toolsUsed: z.string().optional(),
  steps: z.string().optional(),
  mediaType: z.string().optional(),
  mediaUrl: z.string().optional(),
});

export async function getProfile(req: AuthRequest, res: Response) {
  const profile = await studentService.getStudentProfileByUserId(req.user!.id);
  if (!profile) {
    return res.status(404).json({ success: false, message: 'Student profile not found' });
  }
  res.json({ success: true, data: profile });
}

export async function updateProfile(req: AuthRequest, res: Response) {
  const data = profileUpdateSchema.parse(req.body);
  const cleaned = {
    ...data,
    graduationYear: data.graduationYear === null ? undefined : data.graduationYear,
  };
  const profile = await studentService.updateStudentProfile(req.user!.id, cleaned);
  res.json({ success: true, message: 'Profile updated', data: profile });
}

export async function getDashboard(req: AuthRequest, res: Response) {
  const stats = await studentService.getDashboardStats(req.user!.id);
  res.json({ success: true, data: stats });
}

export async function getSkillsCatalog(req: AuthRequest, res: Response) {
  const trade = req.query.trade as string | undefined;
  const skills = await studentService.getSkillsCatalog(trade);
  res.json({ success: true, data: skills });
}

export async function addSkill(req: AuthRequest, res: Response) {
  try {
    const data = addSkillSchema.parse(req.body);
    const skill = await studentService.addStudentSkill(req.user!.id, data);
    res.status(201).json({ success: true, message: 'Skill added', data: skill });
  } catch (err: any) {
    if (err.message === 'Skill already added to your profile') {
      return res.status(409).json({ success: false, message: err.message });
    }
    throw err;
  }
}

export async function removeSkill(req: AuthRequest, res: Response) {
  try {
    await studentService.removeStudentSkill(req.user!.id, req.params.id);
    res.json({ success: true, message: 'Skill removed' });
  } catch (err: any) {
    if (err.message.includes('not found') || err.message.includes('verified')) {
      return res.status(400).json({ success: false, message: err.message });
    }
    throw err;
  }
}

export async function addCertificate(req: AuthRequest, res: Response) {
  const data = certSchema.parse(req.body);
  const cert = await studentService.addCertificate(req.user!.id, data);
  res.status(201).json({ success: true, message: 'Certificate added', data: cert });
}

export async function deleteCertificate(req: AuthRequest, res: Response) {
  try {
    await studentService.deleteCertificate(req.user!.id, req.params.id);
    res.json({ success: true, message: 'Certificate deleted' });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function addProject(req: AuthRequest, res: Response) {
  const data = projectSchema.parse(req.body);
  const project = await studentService.addProject(req.user!.id, {
    ...data,
    url: data.url || undefined,
  });
  res.status(201).json({ success: true, message: 'Project added', data: project });
}

export async function deleteProject(req: AuthRequest, res: Response) {
  try {
    await studentService.deleteProject(req.user!.id, req.params.id);
    res.json({ success: true, message: 'Project deleted' });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function createSubmission(req: AuthRequest, res: Response) {
  const data = submissionSchema.parse(req.body);
  // If file was uploaded via multer
  if (req.file) {
    data.mediaUrl = `/uploads/${req.file.filename}`;
    data.mediaType = req.file.mimetype.startsWith('video')
      ? 'video'
      : req.file.mimetype.startsWith('image')
        ? 'image'
        : 'document';
  }
  const submission = await studentService.createSubmission(req.user!.id, data);
  res.status(201).json({ success: true, message: 'Practical demonstration submitted', data: submission });
}

export async function getSubmissions(req: AuthRequest, res: Response) {
  const submissions = await studentService.getSubmissions(req.user!.id);
  res.json({ success: true, data: submissions });
}

export async function getPassport(req: AuthRequest, res: Response) {
  const passport = await studentService.getSkillPassport(req.user!.id);
  if (!passport) {
    return res.status(404).json({ success: false, message: 'Profile not found' });
  }
  res.json({ success: true, data: passport });
}
