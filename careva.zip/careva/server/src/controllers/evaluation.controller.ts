import { Response } from 'express';
import { z } from 'zod';
import { AuthRequest } from '../middleware/auth.middleware.js';
import * as evaluationService from '../services/evaluation.service.js';
import { DEFAULT_RUBRIC } from '../services/ai/index.js';

export async function runEvaluation(req: AuthRequest, res: Response) {
  const schema = z.object({
    submissionId: z.string().min(1),
  });
  const { submissionId } = schema.parse(req.body);

  try {
    const result = await evaluationService.runEvaluation(req.user!.id, submissionId);
    res.json({
      success: true,
      message: result.verified
        ? 'Evaluation complete — skill verified'
        : 'Evaluation complete — needs improvement',
      data: {
        evaluation: result.evaluation,
        overallScore: result.result.overallScore,
        level: result.result.level,
        rubricScores: result.result.rubricScores,
        strengths: result.result.strengths,
        improvements: result.result.improvements,
        recommendations: result.result.recommendations,
        isDemo: result.result.isDemo,
        providerName: result.result.providerName,
        verified: result.verified,
        credentialId: result.credentialId,
        skillName: result.skillName,
        submissionTitle: result.submissionTitle,
        rubric: DEFAULT_RUBRIC,
      },
    });
  } catch (err: any) {
    if (
      err.message === 'Submission not found' ||
      err.message === 'This submission is already verified' ||
      err.message === 'Student profile not found'
    ) {
      return res.status(400).json({ success: false, message: err.message });
    }
    throw err;
  }
}

export async function getSubmissionEvaluation(req: AuthRequest, res: Response) {
  try {
    const submission = await evaluationService.getEvaluationBySubmission(
      req.user!.id,
      req.params.submissionId
    );
    res.json({ success: true, data: submission });
  } catch (err: any) {
    return res.status(404).json({ success: false, message: err.message });
  }
}

export async function publicVerify(req: AuthRequest, res: Response) {
  const { credentialId } = req.params;
  if (!credentialId) {
    return res.status(400).json({ success: false, message: 'Credential ID required' });
  }

  const data = await evaluationService.verifyCredentialPublic(credentialId);
  if (!data) {
    return res.status(404).json({
      success: false,
      message: 'Credential not found or inactive',
    });
  }

  res.json({
    success: true,
    data,
  });
}

export async function getRubric(_req: AuthRequest, res: Response) {
  res.json({
    success: true,
    data: {
      rubric: DEFAULT_RUBRIC,
      thresholds: {
        BEGINNER: '0–49',
        INTERMEDIATE: '50–74',
        JOB_READY: '75–100',
      },
      note: 'CAREVA AI-Assisted Competency Evaluation uses structured rubrics. Demo Mode generates realistic scores from submission metadata.',
    },
  });
}
