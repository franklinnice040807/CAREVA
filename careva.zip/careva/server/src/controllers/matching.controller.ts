import { Response } from 'express';
import { z } from 'zod';
import { AuthRequest } from '../middleware/auth.middleware.js';
import * as matchingService from '../services/matching/matching.service.js';

export async function matchJobCandidates(req: AuthRequest, res: Response) {
  try {
    const results = await matchingService.matchJobToCandidates(req.params.jobId);
    res.json({ success: true, data: results });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function matchStudentJobs(req: AuthRequest, res: Response) {
  try {
    const results = await matchingService.matchStudentToJobs(req.user!.id);
    res.json({ success: true, data: results });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function getMatchDetail(req: AuthRequest, res: Response) {
  try {
    const { jobId, studentId } = req.params;
    const detail = await matchingService.getMatchDetail(jobId, studentId);
    res.json({ success: true, data: detail });
  } catch (err: any) {
    return res.status(404).json({ success: false, message: err.message });
  }
}

export async function applyToJob(req: AuthRequest, res: Response) {
  const schema = z.object({
    jobId: z.string().min(1),
    coverNote: z.string().max(2000).optional(),
  });
  const data = schema.parse(req.body);
  try {
    const app = await matchingService.applyToJob(req.user!.id, data.jobId, data.coverNote);
    res.status(201).json({ success: true, message: 'Application submitted', data: app });
  } catch (err: any) {
    if (err.message.includes('Already applied') || err.message.includes('not found')) {
      return res.status(400).json({ success: false, message: err.message });
    }
    throw err;
  }
}

export async function getMyApplications(req: AuthRequest, res: Response) {
  try {
    const apps = await matchingService.getStudentApplications(req.user!.id);
    res.json({ success: true, data: apps });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function getCareerInsights(req: AuthRequest, res: Response) {
  try {
    const insights = await matchingService.generateCareerInsights(req.user!.id);
    res.json({ success: true, data: insights });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}
