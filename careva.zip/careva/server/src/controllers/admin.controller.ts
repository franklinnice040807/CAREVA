import { Response } from 'express';
import { AuthRequest } from '../middleware/auth.middleware.js';
import * as adminService from '../services/admin.service.js';

export async function getStats(req: AuthRequest, res: Response) {
  const stats = await adminService.getPlatformStats();
  res.json({ success: true, data: stats });
}

export async function getAnalytics(req: AuthRequest, res: Response) {
  const data = await adminService.getAnalyticsBundle();
  res.json({ success: true, data });
}

export async function getUsers(req: AuthRequest, res: Response) {
  const role = req.query.role as string | undefined;
  const users = await adminService.getUsers(role);
  res.json({ success: true, data: users });
}

export async function getSubmissions(req: AuthRequest, res: Response) {
  const submissions = await adminService.getAllSubmissions();
  res.json({ success: true, data: submissions });
}

export async function getJobs(req: AuthRequest, res: Response) {
  const jobs = await adminService.getAllJobs();
  res.json({ success: true, data: jobs });
}

export async function getSkills(req: AuthRequest, res: Response) {
  const skills = await adminService.getAllSkills();
  res.json({ success: true, data: skills });
}

export async function toggleSkill(req: AuthRequest, res: Response) {
  const { isActive } = req.body;
  const skill = await adminService.toggleSkillActive(req.params.id, !!isActive);
  res.json({ success: true, data: skill });
}
