import { Response } from 'express';
import { z } from 'zod';
import { AuthRequest } from '../middleware/auth.middleware.js';
import * as feedbackService from '../services/feedback.service.js';

const feedbackSchema = z.object({
  applicationId: z.string(),
  practicalScore: z.number().int().min(1).max(5),
  technicalScore: z.number().int().min(1).max(5),
  safetyScore: z.number().int().min(1).max(5),
  reliabilityScore: z.number().int().min(1).max(5),
  communicationScore: z.number().int().min(1).max(5),
  workplaceScore: z.number().int().min(1).max(5),
  writtenFeedback: z.string().max(2000).optional(),
});

export async function submit(req: AuthRequest, res: Response) {
  const data = feedbackSchema.parse(req.body);
  try {
    const feedback = await feedbackService.submitFeedback(req.user!.id, data);
    res.status(201).json({ success: true, message: 'Feedback submitted', data: feedback });
  } catch (err: any) {
    return res.status(400).json({ success: false, message: err.message });
  }
}

export async function list(req: AuthRequest, res: Response) {
  const feedback = await feedbackService.getFeedbackForEmployer(req.user!.id);
  res.json({ success: true, data: feedback });
}

export async function pendingHires(req: AuthRequest, res: Response) {
  const hires = await feedbackService.getHiresForFeedback(req.user!.id);
  res.json({ success: true, data: hires });
}
