import { Response } from 'express';
import { z } from 'zod';
import { registerUser, loginUser, getUserById } from '../services/auth/auth.service.js';
import { AuthRequest } from '../middleware/auth.middleware.js';

const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  role: z.enum(['STUDENT', 'EMPLOYER']),
  fullName: z.string().min(2).optional(),
  companyName: z.string().min(2).optional(),
}).refine(
  (data) => {
    if (data.role === 'STUDENT') return !!data.fullName;
    if (data.role === 'EMPLOYER') return !!data.companyName;
    return true;
  },
  { message: 'Full name required for students, company name required for employers' }
);

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

export async function register(req: AuthRequest, res: Response) {
  try {
    const data = registerSchema.parse(req.body);
    const result = await registerUser(data);
    res.status(201).json({
      success: true,
      message: 'Registration successful',
      data: result,
    });
  } catch (err: any) {
    if (err.message === 'Email already registered') {
      return res.status(409).json({ success: false, message: err.message });
    }
    throw err;
  }
}

export async function login(req: AuthRequest, res: Response) {
  try {
    const data = loginSchema.parse(req.body);
    const result = await loginUser(data.email, data.password);
    res.json({
      success: true,
      message: 'Login successful',
      data: result,
    });
  } catch (err: any) {
    if (err.message === 'Invalid email or password') {
      return res.status(401).json({ success: false, message: err.message });
    }
    throw err;
  }
}

export async function me(req: AuthRequest, res: Response) {
  if (!req.user) {
    return res.status(401).json({ success: false, message: 'Not authenticated' });
  }

  const user = await getUserById(req.user.id);
  if (!user) {
    return res.status(401).json({ success: false, message: 'User not found' });
  }

  res.json({
    success: true,
    data: { user },
  });
}

export async function logout(_req: AuthRequest, res: Response) {
  // JWT is stateless; client discards token
  res.json({ success: true, message: 'Logged out successfully' });
}
