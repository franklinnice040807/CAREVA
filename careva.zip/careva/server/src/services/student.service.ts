import { CompetencyLevel, SubmissionStatus } from '@prisma/client';
import prisma from '../database/prisma.js';

export async function getStudentProfileByUserId(userId: string) {
  const profile = await prisma.studentProfile.findUnique({
    where: { userId },
    include: {
      skills: {
        include: { skill: true, credential: true },
        orderBy: { createdAt: 'desc' },
      },
      certificates: { orderBy: { createdAt: 'desc' } },
      projects: { orderBy: { createdAt: 'desc' } },
      submissions: {
        include: { skill: true, evaluations: { orderBy: { evaluatedAt: 'desc' }, take: 1 } },
        orderBy: { createdAt: 'desc' },
      },
      user: { select: { email: true } },
    },
  });
  return profile;
}

export async function updateStudentProfile(
  userId: string,
  data: {
    fullName?: string;
    phone?: string;
    location?: string;
    institute?: string;
    course?: string;
    trade?: string;
    graduationYear?: number;
    about?: string;
    experienceYears?: number;
    profileImage?: string;
  }
) {
  const profile = await prisma.studentProfile.update({
    where: { userId },
    data: {
      ...data,
      profileCompletion: await calculateProfileCompletion(userId, data),
    },
    include: {
      skills: { include: { skill: true } },
      certificates: true,
      projects: true,
      user: { select: { email: true } },
    },
  });
  return profile;
}

async function calculateProfileCompletion(userId: string, updates: Record<string, unknown> = {}) {
  const current = await prisma.studentProfile.findUnique({
    where: { userId },
    include: {
      skills: true,
      certificates: true,
      projects: true,
      submissions: true,
    },
  });
  if (!current) return 0;

  const merged = { ...current, ...updates };
  let score = 10; // base for having account

  if (merged.fullName) score += 10;
  if (merged.phone) score += 5;
  if (merged.location) score += 5;
  if (merged.institute) score += 10;
  if (merged.course) score += 5;
  if (merged.trade) score += 10;
  if (merged.graduationYear) score += 5;
  if (merged.about) score += 10;
  if (merged.profileImage) score += 5;
  if ((current.skills?.length || 0) > 0) score += 10;
  if ((current.certificates?.length || 0) > 0) score += 5;
  if ((current.projects?.length || 0) > 0) score += 5;
  if ((current.submissions?.length || 0) > 0) score += 5;

  return Math.min(100, score);
}

export async function getSkillsCatalog(trade?: string) {
  return prisma.skill.findMany({
    where: {
      isActive: true,
      ...(trade ? { trade } : {}),
    },
    orderBy: [{ trade: 'asc' }, { name: 'asc' }],
  });
}

export async function addStudentSkill(
  userId: string,
  data: {
    skillId: string;
    selfAssessedLevel?: CompetencyLevel;
    experienceNotes?: string;
  }
) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const existing = await prisma.studentSkill.findUnique({
    where: { studentId_skillId: { studentId: profile.id, skillId: data.skillId } },
  });
  if (existing) throw new Error('Skill already added to your profile');

  const studentSkill = await prisma.studentSkill.create({
    data: {
      studentId: profile.id,
      skillId: data.skillId,
      selfAssessedLevel: data.selfAssessedLevel,
      experienceNotes: data.experienceNotes,
    },
    include: { skill: true },
  });

  await prisma.studentProfile.update({
    where: { id: profile.id },
    data: { profileCompletion: await calculateProfileCompletion(userId) },
  });

  return studentSkill;
}

export async function removeStudentSkill(userId: string, studentSkillId: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const skill = await prisma.studentSkill.findFirst({
    where: { id: studentSkillId, studentId: profile.id },
  });
  if (!skill) throw new Error('Skill not found');
  if (skill.isVerified) throw new Error('Cannot remove a verified skill');

  await prisma.studentSkill.delete({ where: { id: studentSkillId } });
  return { success: true };
}

export async function addCertificate(
  userId: string,
  data: { title: string; issuer?: string; issueDate?: string; fileUrl?: string }
) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const cert = await prisma.certificate.create({
    data: {
      studentId: profile.id,
      title: data.title,
      issuer: data.issuer,
      issueDate: data.issueDate ? new Date(data.issueDate) : null,
      fileUrl: data.fileUrl,
    },
  });

  await prisma.studentProfile.update({
    where: { id: profile.id },
    data: { profileCompletion: await calculateProfileCompletion(userId) },
  });

  return cert;
}

export async function deleteCertificate(userId: string, certId: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const cert = await prisma.certificate.findFirst({
    where: { id: certId, studentId: profile.id },
  });
  if (!cert) throw new Error('Certificate not found');

  await prisma.certificate.delete({ where: { id: certId } });
  return { success: true };
}

export async function addProject(
  userId: string,
  data: { title: string; description?: string; skillsUsed?: string[]; url?: string }
) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const project = await prisma.project.create({
    data: {
      studentId: profile.id,
      title: data.title,
      description: data.description,
      skillsUsed: data.skillsUsed || [],
      url: data.url,
    },
  });

  await prisma.studentProfile.update({
    where: { id: profile.id },
    data: { profileCompletion: await calculateProfileCompletion(userId) },
  });

  return project;
}

export async function deleteProject(userId: string, projectId: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const project = await prisma.project.findFirst({
    where: { id: projectId, studentId: profile.id },
  });
  if (!project) throw new Error('Project not found');

  await prisma.project.delete({ where: { id: projectId } });
  return { success: true };
}

export async function createSubmission(
  userId: string,
  data: {
    skillId: string;
    title: string;
    description: string;
    toolsUsed?: string;
    steps?: string;
    mediaType?: string;
    mediaUrl?: string;
  }
) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  // Ensure skill is on profile or add it
  let studentSkill = await prisma.studentSkill.findUnique({
    where: { studentId_skillId: { studentId: profile.id, skillId: data.skillId } },
  });
  if (!studentSkill) {
    studentSkill = await prisma.studentSkill.create({
      data: {
        studentId: profile.id,
        skillId: data.skillId,
        selfAssessedLevel: CompetencyLevel.BEGINNER,
      },
    });
  }

  const submission = await prisma.skillSubmission.create({
    data: {
      studentId: profile.id,
      skillId: data.skillId,
      title: data.title,
      description: data.description,
      toolsUsed: data.toolsUsed,
      steps: data.steps,
      mediaType: data.mediaType,
      mediaUrl: data.mediaUrl,
      status: SubmissionStatus.SUBMITTED,
    },
    include: { skill: true },
  });

  await prisma.studentProfile.update({
    where: { id: profile.id },
    data: { profileCompletion: await calculateProfileCompletion(userId) },
  });

  // Create notification
  await prisma.notification.create({
    data: {
      userId,
      type: 'SUBMISSION_RECEIVED',
      title: 'Practical demonstration submitted',
      message: `Your submission "${data.title}" has been received and is ready for evaluation.`,
      link: '/student/submissions',
    },
  });

  return submission;
}

export async function getSubmissions(userId: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  return prisma.skillSubmission.findMany({
    where: { studentId: profile.id },
    include: {
      skill: true,
      evaluations: { orderBy: { evaluatedAt: 'desc' } },
    },
    orderBy: { createdAt: 'desc' },
  });
}

export async function getSkillPassport(userId: string) {
  const profile = await prisma.studentProfile.findUnique({
    where: { userId },
    include: {
      skills: {
        where: { isVerified: true },
        include: { skill: true, credential: true },
        orderBy: { competencyScore: 'desc' },
      },
      certificates: true,
      projects: true,
      feedbackReceived: {
        orderBy: { createdAt: 'desc' },
        take: 10,
      },
      user: { select: { email: true } },
    },
  });
  return profile;
}

export async function getDashboardStats(userId: string) {
  const profile = await prisma.studentProfile.findUnique({
    where: { userId },
    include: {
      skills: true,
      submissions: true,
      jobMatches: {
        orderBy: { overallScore: 'desc' },
        take: 5,
        include: {
          job: {
            include: {
              employer: true,
              requirements: { include: { skill: true } },
            },
          },
        },
      },
    },
  });

  if (!profile) throw new Error('Student profile not found');

  const verifiedSkills = profile.skills.filter((s) => s.isVerified);
  const avgScore =
    verifiedSkills.length > 0
      ? verifiedSkills.reduce((sum, s) => sum + (s.competencyScore || 0), 0) / verifiedSkills.length
      : 0;

  return {
    profileCompletion: profile.profileCompletion,
    verifiedSkillsCount: verifiedSkills.length,
    totalSkillsCount: profile.skills.length,
    overallCompetencyScore: Math.round(avgScore),
    jobMatchesCount: profile.jobMatches.length,
    submissionsCount: profile.submissions.length,
    pendingSubmissions: profile.submissions.filter((s) => s.status === 'SUBMITTED' || s.status === 'UNDER_EVALUATION').length,
    recentMatches: profile.jobMatches,
  };
}
