import { CompetencyLevel } from '@prisma/client';

export interface RubricCategory {
  key: string;
  label: string;
  description: string;
  weight: number;
}

export interface EvaluationInput {
  skillName: string;
  skillCategory: string;
  skillTrade: string;
  title: string;
  description: string;
  toolsUsed?: string | null;
  steps?: string | null;
  mediaType?: string | null;
  selfAssessedLevel?: CompetencyLevel | null;
}

export interface EvaluationResult {
  rubricScores: Record<string, number>;
  overallScore: number;
  level: CompetencyLevel;
  strengths: string[];
  improvements: string[];
  recommendations: string[];
  isDemo: boolean;
  providerName: string;
}

export interface AIProvider {
  readonly name: string;
  evaluate(input: EvaluationInput, rubric: RubricCategory[]): Promise<EvaluationResult>;
}

export const DEFAULT_RUBRIC: RubricCategory[] = [
  { key: 'toolHandling', label: 'Tool Handling', description: 'Correct and safe use of tools and equipment', weight: 1 },
  { key: 'safety', label: 'Safety', description: 'Adherence to safety procedures and PPE', weight: 1.2 },
  { key: 'processExecution', label: 'Process Execution', description: 'Correct sequence and technique', weight: 1.1 },
  { key: 'accuracy', label: 'Accuracy', description: 'Precision and dimensional accuracy', weight: 1 },
  { key: 'quality', label: 'Quality', description: 'Finish quality and workmanship standards', weight: 1.1 },
  { key: 'completion', label: 'Completion', description: 'Task completeness and thoroughness', weight: 0.9 },
  { key: 'workplaceReadiness', label: 'Workplace Readiness', description: 'Professional practices and readiness for work', weight: 1 },
];

export const COMPETENCY_THRESHOLDS = {
  BEGINNER: { min: 0, max: 49 },
  INTERMEDIATE: { min: 50, max: 74 },
  JOB_READY: { min: 75, max: 100 },
};

export function scoreToLevel(score: number): CompetencyLevel {
  if (score >= COMPETENCY_THRESHOLDS.JOB_READY.min) return 'JOB_READY';
  if (score >= COMPETENCY_THRESHOLDS.INTERMEDIATE.min) return 'INTERMEDIATE';
  return 'BEGINNER';
}
