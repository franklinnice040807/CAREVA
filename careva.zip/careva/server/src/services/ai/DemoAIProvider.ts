import { CompetencyLevel } from '@prisma/client';
import {
  AIProvider,
  EvaluationInput,
  EvaluationResult,
  RubricCategory,
  scoreToLevel,
} from './types.js';

/**
 * CAREVA Demo AI Provider
 * Generates realistic, deterministic competency scores from submission metadata.
 * Does NOT claim computer vision or real model inference.
 * Clearly labeled as Demo Mode in UI and result payload.
 */
export class DemoAIProvider implements AIProvider {
  readonly name = 'CAREVA Demo AI';

  async evaluate(input: EvaluationInput, rubric: RubricCategory[]): Promise<EvaluationResult> {
    // Simulate processing delay (800–1500ms) for realistic UX
    await new Promise((r) => setTimeout(r, 800 + Math.random() * 700));

    const base = this.computeBaseScore(input);
    const rubricScores: Record<string, number> = {};

    for (const cat of rubric) {
      const variance = this.categoryVariance(cat.key, input);
      let score = base + variance;
      score = Math.max(35, Math.min(98, Math.round(score)));
      rubricScores[cat.key] = score;
    }

    // Weighted overall
    let totalWeight = 0;
    let weightedSum = 0;
    for (const cat of rubric) {
      weightedSum += (rubricScores[cat.key] || 0) * cat.weight;
      totalWeight += cat.weight;
    }
    const overallScore = Math.round(weightedSum / totalWeight);
    const level = scoreToLevel(overallScore);

    const { strengths, improvements, recommendations } = this.generateInsights(
      rubricScores,
      rubric,
      overallScore,
      level,
      input
    );

    return {
      rubricScores,
      overallScore,
      level,
      strengths,
      improvements,
      recommendations,
      isDemo: true,
      providerName: this.name,
    };
  }

  private computeBaseScore(input: EvaluationInput): number {
    let score = 62; // neutral baseline

    // Description quality
    const descLen = (input.description || '').length;
    if (descLen > 200) score += 8;
    else if (descLen > 100) score += 5;
    else if (descLen > 40) score += 2;
    else score -= 5;

    // Steps detail
    const steps = input.steps || '';
    const stepLines = steps.split(/\n|;|\d+\./).filter((s) => s.trim().length > 5);
    if (stepLines.length >= 5) score += 7;
    else if (stepLines.length >= 3) score += 4;
    else if (stepLines.length >= 1) score += 1;

    // Tools mentioned
    if (input.toolsUsed && input.toolsUsed.length > 10) score += 5;
    else if (input.toolsUsed && input.toolsUsed.length > 0) score += 2;

    // Media evidence present
    if (input.mediaType === 'video') score += 6;
    else if (input.mediaType === 'image') score += 4;
    else if (input.mediaType === 'document') score += 2;

    // Self-assessment alignment (slight boost if intermediate/job-ready claimed with detail)
    if (input.selfAssessedLevel === 'JOB_READY' && descLen > 100) score += 3;
    if (input.selfAssessedLevel === 'BEGINNER') score -= 2;

    // Trade-specific keyword signals
    score += this.keywordBoost(input);

    // Deterministic hash from title for slight unique variance
    score += (this.simpleHash(input.title) % 7) - 3;

    return Math.max(40, Math.min(92, score));
  }

  private categoryVariance(key: string, input: EvaluationInput): number {
    const text = `${input.description} ${input.toolsUsed || ''} ${input.steps || ''}`.toLowerCase();
    const map: Record<string, number> = {
      toolHandling: text.includes('tool') || text.includes('equipment') || text.includes('handle') ? 4 : -2,
      safety: text.includes('safety') || text.includes('ppe') || text.includes('helmet') || text.includes('glove') ? 8 : -3,
      processExecution: text.includes('step') || text.includes('procedure') || text.includes('sequence') ? 5 : 0,
      accuracy: text.includes('measure') || text.includes('tolerance') || text.includes('align') || text.includes('accurate') ? 6 : -1,
      quality: text.includes('quality') || text.includes('finish') || text.includes('inspect') ? 5 : 0,
      completion: text.includes('complete') || text.includes('finished') || text.includes('done') ? 3 : -1,
      workplaceReadiness: text.includes('professional') || text.includes('workplace') || text.includes('standard') ? 4 : 0,
    };
    return map[key] ?? 0;
  }

  private keywordBoost(input: EvaluationInput): number {
    const text = `${input.description} ${input.toolsUsed || ''}`.toLowerCase();
    const tradeKeywords: Record<string, string[]> = {
      Electrical: ['wire', 'circuit', 'voltage', 'panel', 'plc', 'motor', 'earthing', 'conduit'],
      Welding: ['weld', 'mig', 'tig', 'arc', 'bead', 'joint', 'electrode', 'gas'],
      Mechanical: ['fit', 'align', 'bearing', 'assembly', 'tolerance', 'cnc', 'lathe'],
      Electronics: ['pcb', 'solder', 'circuit', 'component', 'test', 'multimeter'],
      Automobile: ['engine', 'brake', 'diagnostic', 'service', 'oil', 'transmission'],
    };
    const keywords = tradeKeywords[input.skillTrade] || [];
    let boost = 0;
    for (const kw of keywords) {
      if (text.includes(kw)) boost += 1.5;
    }
    return Math.min(8, boost);
  }

  private simpleHash(str: string): number {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = (h << 5) - h + str.charCodeAt(i);
      h |= 0;
    }
    return Math.abs(h);
  }

  private generateInsights(
    scores: Record<string, number>,
    rubric: RubricCategory[],
    overall: number,
    level: CompetencyLevel,
    input: EvaluationInput
  ) {
    const sorted = [...rubric].sort((a, b) => (scores[b.key] || 0) - (scores[a.key] || 0));
    const top = sorted.slice(0, 2);
    const bottom = sorted.slice(-2).reverse();

    const strengths = top.map((c) => {
      const s = scores[c.key];
      if (s >= 85) return `Strong performance in ${c.label} (${s}%) — demonstrates solid practical command.`;
      return `Good competence in ${c.label} (${s}%).`;
    });

    const improvements = bottom.map((c) => {
      const s = scores[c.key];
      if (s < 60) return `${c.label} needs focused practice (scored ${s}%). Review fundamentals and safety/process standards.`;
      return `Opportunity to strengthen ${c.label} (scored ${s}%).`;
    });

    const recommendations: string[] = [];
    if (level === 'BEGINNER') {
      recommendations.push(`Complete guided practice sessions for ${input.skillName} under supervisor observation.`);
      recommendations.push('Re-submit a practical demonstration after focused practice on weaker rubric areas.');
    } else if (level === 'INTERMEDIATE') {
      recommendations.push(`Aim for job-ready level by improving consistency in ${bottom[0]?.label || 'weaker areas'}.`);
      recommendations.push('Document more detailed process steps and safety checks in the next submission.');
    } else {
      recommendations.push(`Maintain standards and consider advanced ${input.skillName} challenges or related multi-skill projects.`);
      recommendations.push('Share this verified skill on your CAREVA Skill Passport with employers.');
    }
    if (!(input.toolsUsed && input.toolsUsed.length > 5)) {
      recommendations.push('Include specific tools and equipment used in future demonstrations for richer evaluation.');
    }

    return { strengths, improvements, recommendations };
  }
}
