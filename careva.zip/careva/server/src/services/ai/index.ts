import { AIProvider } from './types.js';
import { DemoAIProvider } from './DemoAIProvider.js';

/**
 * AI Provider factory.
 * Switch via AI_PROVIDER env: demo | openai | gemini (future)
 */
export function getAIProvider(): AIProvider {
  const provider = (process.env.AI_PROVIDER || 'demo').toLowerCase();

  switch (provider) {
    case 'demo':
    default:
      return new DemoAIProvider();
    // Future:
    // case 'openai': return new OpenAIProvider(process.env.AI_API_KEY);
    // case 'gemini': return new GeminiProvider(process.env.AI_API_KEY);
  }
}

export * from './types.js';
export { DemoAIProvider } from './DemoAIProvider.js';
