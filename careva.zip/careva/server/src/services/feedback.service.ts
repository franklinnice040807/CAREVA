import prisma from '../database/prisma.js';

export async function submitFeedback(
  userId: string,
  data: {
    applicationId: string;
    practicalScore: number;
    technicalScore: number;
    safetyScore: number;
    reliabilityScore: number;
    communicationScore: number;
    workplaceScore: number;
    writtenFeedback?: string;
  }
) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const application = await prisma.application.findFirst({
    where: {
      id: data.applicationId,
      job: { employerId: profile.id },
      status: 'HIRED',
    },
    include: { student: true, job: true },
  });
  if (!application) throw new Error('Hired application not found');

  const existing = await prisma.employerFeedback.findUnique({
    where: { applicationId: data.applicationId },
  });
  if (existing) throw new Error('Feedback already submitted for this hire');

  const feedback = await prisma.employerFeedback.create({
    data: {
      applicationId: data.applicationId,
      studentId: application.studentId,
      practicalScore: data.practicalScore,
      technicalScore: data.technicalScore,
      safetyScore: data.safetyScore,
      reliabilityScore: data.reliabilityScore,
      communicationScore: data.communicationScore,
      workplaceScore: data.workplaceScore,
      writtenFeedback: data.writtenFeedback,
    },
  });

  // Notify student
  await prisma.notification.create({
    data: {
      userId: application.student.userId,
      type: 'EMPLOYER_FEEDBACK',
      title: 'Employer feedback received',
      message: `You received performance feedback for your role at the hiring company.`,
      link: '/student/passport',
    },
  });

  return feedback;
}

export async function getFeedbackForEmployer(userId: string) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  return prisma.employerFeedback.findMany({
    where: {
      application: { job: { employerId: profile.id } },
    },
    include: {
      student: { select: { id: true, fullName: true, trade: true } },
      application: {
        include: { job: { select: { title: true } } },
      },
    },
    orderBy: { createdAt: 'desc' },
  });
}

export async function getHiresForFeedback(userId: string) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  return prisma.application.findMany({
    where: {
      status: 'HIRED',
      job: { employerId: profile.id },
      feedback: null,
    },
    include: {
      student: { select: { id: true, fullName: true, trade: true } },
      job: { select: { title: true } },
    },
  });
}
