import prisma from '../database/prisma.js';

export async function getPlatformStats() {
  const [
    students,
    employers,
    verifiedSkills,
    submissions,
    jobs,
    matches,
    hires,
    applications,
  ] = await Promise.all([
    prisma.studentProfile.count(),
    prisma.employerProfile.count(),
    prisma.studentSkill.count({ where: { isVerified: true } }),
    prisma.skillSubmission.count(),
    prisma.job.count(),
    prisma.jobMatch.count(),
    prisma.application.count({ where: { status: 'HIRED' } }),
    prisma.application.count(),
  ]);

  return {
    students,
    employers,
    verifiedSkills,
    submissions,
    jobs,
    matches,
    hires,
    applications,
  };
}

export async function getStudentsByTrade() {
  const students = await prisma.studentProfile.groupBy({
    by: ['trade'],
    _count: { id: true },
  });
  return students
    .filter((s) => s.trade)
    .map((s) => ({ trade: s.trade!, count: s._count.id }))
    .sort((a, b) => b.count - a.count);
}

export async function getCompetencyDistribution() {
  const skills = await prisma.studentSkill.findMany({
    where: { isVerified: true },
    select: { verifiedLevel: true, competencyScore: true },
  });

  const dist = { BEGINNER: 0, INTERMEDIATE: 0, JOB_READY: 0 };
  for (const s of skills) {
    if (s.verifiedLevel && dist[s.verifiedLevel] !== undefined) {
      dist[s.verifiedLevel]++;
    }
  }
  return dist;
}

export async function getMostRequestedSkills() {
  const reqs = await prisma.jobRequirement.groupBy({
    by: ['skillId'],
    _count: { id: true },
    orderBy: { _count: { id: 'desc' } },
    take: 10,
  });

  const skillIds = reqs.map((r) => r.skillId);
  const skills = await prisma.skill.findMany({
    where: { id: { in: skillIds } },
  });
  const skillMap = Object.fromEntries(skills.map((s) => [s.id, s]));

  return reqs.map((r) => ({
    skillId: r.skillId,
    name: skillMap[r.skillId]?.name || 'Unknown',
    trade: skillMap[r.skillId]?.trade || '',
    count: r._count.id,
  }));
}

export async function getJobDemandByTrade() {
  const jobs = await prisma.job.groupBy({
    by: ['trade'],
    where: { isActive: true },
    _count: { id: true },
  });
  return jobs
    .map((j) => ({ trade: j.trade, count: j._count.id }))
    .sort((a, b) => b.count - a.count);
}

export async function getVerificationActivity() {
  const recent = await prisma.studentSkill.findMany({
    where: { isVerified: true, verificationDate: { not: null } },
    orderBy: { verificationDate: 'desc' },
    take: 20,
    include: {
      skill: true,
      student: { select: { fullName: true, trade: true } },
    },
  });
  return recent.map((s) => ({
    skillName: s.skill.name,
    studentName: s.student.fullName,
    trade: s.student.trade,
    level: s.verifiedLevel,
    score: s.competencyScore,
    date: s.verificationDate,
  }));
}

export async function getHiringOutcomes() {
  const byStatus = await prisma.application.groupBy({
    by: ['status'],
    _count: { id: true },
  });
  return byStatus.map((s) => ({ status: s.status, count: s._count.id }));
}

export async function getUsers(role?: string) {
  return prisma.user.findMany({
    where: role ? { role: role as any } : undefined,
    include: {
      studentProfile: { select: { fullName: true, trade: true, profileCompletion: true } },
      employerProfile: { select: { companyName: true, industry: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
}

export async function getAllSubmissions() {
  return prisma.skillSubmission.findMany({
    include: {
      skill: true,
      student: { select: { fullName: true, trade: true } },
      evaluations: { orderBy: { evaluatedAt: 'desc' }, take: 1 },
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
}

export async function getAllJobs() {
  return prisma.job.findMany({
    include: {
      employer: { select: { companyName: true } },
      requirements: { include: { skill: true } },
      _count: { select: { applications: true, matches: true } },
    },
    orderBy: { createdAt: 'desc' },
  });
}

export async function getAllSkills() {
  return prisma.skill.findMany({
    orderBy: [{ trade: 'asc' }, { name: 'asc' }],
  });
}

export async function toggleSkillActive(skillId: string, isActive: boolean) {
  return prisma.skill.update({
    where: { id: skillId },
    data: { isActive },
  });
}

export async function getAnalyticsBundle() {
  const [
    stats,
    studentsByTrade,
    competencyDist,
    mostRequested,
    jobDemand,
    verificationActivity,
    hiringOutcomes,
  ] = await Promise.all([
    getPlatformStats(),
    getStudentsByTrade(),
    getCompetencyDistribution(),
    getMostRequestedSkills(),
    getJobDemandByTrade(),
    getVerificationActivity(),
    getHiringOutcomes(),
  ]);

  return {
    stats,
    studentsByTrade,
    competencyDist,
    mostRequested,
    jobDemand,
    verificationActivity,
    hiringOutcomes,
  };
}
