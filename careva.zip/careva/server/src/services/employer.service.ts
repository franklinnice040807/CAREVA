import { CompetencyLevel, EmploymentType, ApplicationStatus } from '@prisma/client';
import prisma from '../database/prisma.js';

export async function getEmployerProfile(userId: string) {
  return prisma.employerProfile.findUnique({
    where: { userId },
    include: {
      user: { select: { email: true } },
      jobs: {
        include: {
          requirements: { include: { skill: true } },
          _count: { select: { applications: true, matches: true } },
        },
        orderBy: { createdAt: 'desc' },
      },
    },
  });
}

export async function updateEmployerProfile(
  userId: string,
  data: {
    companyName?: string;
    industry?: string;
    location?: string;
    website?: string;
    description?: string;
    companySize?: string;
    contactInfo?: string;
    logo?: string;
  }
) {
  return prisma.employerProfile.update({
    where: { userId },
    data,
    include: { user: { select: { email: true } } },
  });
}

export async function getDashboardStats(userId: string) {
  const profile = await prisma.employerProfile.findUnique({
    where: { userId },
    include: {
      jobs: {
        include: {
          applications: true,
          matches: true,
          shortlists: true,
        },
      },
      shortlists: true,
    },
  });
  if (!profile) throw new Error('Employer profile not found');

  const activeJobs = profile.jobs.filter((j) => j.isActive);
  const allApps = profile.jobs.flatMap((j) => j.applications);
  const allMatches = profile.jobs.flatMap((j) => j.matches);
  const hires = allApps.filter((a) => a.status === 'HIRED').length;
  const shortlisted = allApps.filter((a) => a.status === 'SHORTLISTED').length;

  // Recent applications
  const recentApplications = await prisma.application.findMany({
    where: { job: { employerId: profile.id } },
    include: {
      student: {
        select: {
          id: true,
          fullName: true,
          trade: true,
          location: true,
          carevaId: true,
          skills: {
            where: { isVerified: true },
            include: { skill: true },
            take: 5,
          },
        },
      },
      job: { select: { id: true, title: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 8,
  });

  // Top matched candidates across active jobs
  const topMatches = await prisma.jobMatch.findMany({
    where: { job: { employerId: profile.id, isActive: true } },
    include: {
      student: {
        select: {
          id: true,
          fullName: true,
          trade: true,
          location: true,
          experienceYears: true,
          skills: {
            where: { isVerified: true },
            include: { skill: true },
            take: 4,
          },
        },
      },
      job: { select: { id: true, title: true } },
    },
    orderBy: { overallScore: 'desc' },
    take: 6,
  });

  return {
    activeJobs: activeJobs.length,
    totalJobs: profile.jobs.length,
    candidatesMatched: allMatches.length,
    applications: allApps.length,
    shortlisted,
    hires,
    recentApplications,
    topMatches,
  };
}

export async function createJob(
  userId: string,
  data: {
    title: string;
    description: string;
    trade: string;
    location?: string;
    salaryRange?: string;
    employmentType?: EmploymentType;
    requiredCompetency?: CompetencyLevel;
    experienceRequired?: number;
    requirements: Array<{ skillId: string; requiredLevel?: CompetencyLevel }>;
  }
) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const job = await prisma.job.create({
    data: {
      employerId: profile.id,
      title: data.title,
      description: data.description,
      trade: data.trade,
      location: data.location,
      salaryRange: data.salaryRange,
      employmentType: data.employmentType || 'FULL_TIME',
      requiredCompetency: data.requiredCompetency || 'INTERMEDIATE',
      experienceRequired: data.experienceRequired || 0,
      requirements: {
        create: data.requirements.map((r) => ({
          skillId: r.skillId,
          requiredLevel: r.requiredLevel || 'INTERMEDIATE',
        })),
      },
    },
    include: {
      requirements: { include: { skill: true } },
      employer: true,
    },
  });

  return job;
}

export async function updateJob(
  userId: string,
  jobId: string,
  data: {
    title?: string;
    description?: string;
    trade?: string;
    location?: string;
    salaryRange?: string;
    employmentType?: EmploymentType;
    requiredCompetency?: CompetencyLevel;
    experienceRequired?: number;
    isActive?: boolean;
  }
) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const job = await prisma.job.findFirst({
    where: { id: jobId, employerId: profile.id },
  });
  if (!job) throw new Error('Job not found');

  return prisma.job.update({
    where: { id: jobId },
    data,
    include: {
      requirements: { include: { skill: true } },
      _count: { select: { applications: true, matches: true } },
    },
  });
}

export async function getJobs(userId: string) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  return prisma.job.findMany({
    where: { employerId: profile.id },
    include: {
      requirements: { include: { skill: true } },
      _count: { select: { applications: true, matches: true } },
    },
    orderBy: { createdAt: 'desc' },
  });
}

export async function getJobById(userId: string, jobId: string) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const job = await prisma.job.findFirst({
    where: { id: jobId, employerId: profile.id },
    include: {
      requirements: { include: { skill: true } },
      applications: {
        include: {
          student: {
            select: {
              id: true,
              fullName: true,
              trade: true,
              location: true,
              experienceYears: true,
              carevaId: true,
              skills: {
                where: { isVerified: true },
                include: { skill: true },
              },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      },
      matches: {
        include: {
          student: {
            select: {
              id: true,
              fullName: true,
              trade: true,
              location: true,
              experienceYears: true,
              skills: {
                where: { isVerified: true },
                include: { skill: true },
                take: 5,
              },
            },
          },
        },
        orderBy: { overallScore: 'desc' },
      },
    },
  });
  if (!job) throw new Error('Job not found');
  return job;
}

export async function searchCandidates(
  userId: string,
  filters: {
    trade?: string;
    skillId?: string;
    competency?: CompetencyLevel;
    location?: string;
    minExperience?: number;
    sort?: 'match' | 'score' | 'experience' | 'recent';
    jobId?: string;
  }
) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const where: any = {};
  if (filters.trade) where.trade = filters.trade;
  if (filters.location) where.location = { contains: filters.location, mode: 'insensitive' };
  if (filters.minExperience != null) where.experienceYears = { gte: filters.minExperience };

  if (filters.skillId || filters.competency) {
    where.skills = {
      some: {
        isVerified: true,
        ...(filters.skillId ? { skillId: filters.skillId } : {}),
        ...(filters.competency ? { verifiedLevel: filters.competency } : {}),
      },
    };
  }

  const students = await prisma.studentProfile.findMany({
    where,
    include: {
      skills: {
        where: { isVerified: true },
        include: { skill: true, credential: true },
      },
      user: { select: { email: true } },
    },
    take: 50,
  });

  // If jobId provided, attach match scores if they exist
  let matchMap: Record<string, number> = {};
  if (filters.jobId) {
    const matches = await prisma.jobMatch.findMany({
      where: { jobId: filters.jobId },
    });
    matchMap = Object.fromEntries(matches.map((m) => [m.studentId, m.overallScore]));
  }

  let results = students.map((s) => ({
    ...s,
    matchScore: matchMap[s.id] ?? null,
    verifiedSkillsCount: s.skills.length,
    avgCompetency:
      s.skills.length > 0
        ? Math.round(s.skills.reduce((sum, sk) => sum + (sk.competencyScore || 0), 0) / s.skills.length)
        : 0,
  }));

  // Sort
  switch (filters.sort) {
    case 'score':
      results.sort((a, b) => b.avgCompetency - a.avgCompetency);
      break;
    case 'experience':
      results.sort((a, b) => b.experienceYears - a.experienceYears);
      break;
    case 'recent':
      results.sort((a, b) => {
        const aDate = a.skills[0]?.verificationDate?.getTime() || 0;
        const bDate = b.skills[0]?.verificationDate?.getTime() || 0;
        return bDate - aDate;
      });
      break;
    case 'match':
    default:
      results.sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0));
      break;
  }

  return results;
}

export async function getCandidatePassport(userId: string, studentId: string) {
  // Employer can view public-ish passport of a student
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const student = await prisma.studentProfile.findUnique({
    where: { id: studentId },
    include: {
      skills: {
        where: { isVerified: true },
        include: { skill: true, credential: true },
        orderBy: { competencyScore: 'desc' },
      },
      certificates: true,
      projects: true,
      feedbackReceived: { take: 5, orderBy: { createdAt: 'desc' } },
    },
  });
  if (!student) throw new Error('Candidate not found');

  // Strip private fields
  return {
    id: student.id,
    fullName: student.fullName,
    trade: student.trade,
    location: student.location,
    institute: student.institute,
    course: student.course,
    graduationYear: student.graduationYear,
    about: student.about,
    experienceYears: student.experienceYears,
    carevaId: student.carevaId,
    skills: student.skills,
    certificates: student.certificates,
    projects: student.projects,
    feedbackReceived: student.feedbackReceived,
  };
}

export async function updateApplicationStatus(
  userId: string,
  applicationId: string,
  status: ApplicationStatus,
  notes?: string
) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const app = await prisma.application.findFirst({
    where: { id: applicationId, job: { employerId: profile.id } },
    include: { student: true, job: true },
  });
  if (!app) throw new Error('Application not found');

  const updated = await prisma.application.update({
    where: { id: applicationId },
    data: { status },
    include: {
      student: { select: { id: true, fullName: true, userId: true } },
      job: { select: { title: true } },
    },
  });

  // Notify student
  await prisma.notification.create({
    data: {
      userId: updated.student.userId,
      type: 'APPLICATION_UPDATE',
      title: `Application ${status.toLowerCase().replace('_', ' ')}`,
      message: `Your application for "${updated.job.title}" is now: ${status}.`,
      link: '/student/jobs',
    },
  });

  return updated;
}

export async function getApplications(userId: string, jobId?: string) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  return prisma.application.findMany({
    where: {
      job: { employerId: profile.id },
      ...(jobId ? { jobId } : {}),
    },
    include: {
      student: {
        select: {
          id: true,
          fullName: true,
          trade: true,
          location: true,
          experienceYears: true,
          carevaId: true,
          skills: {
            where: { isVerified: true },
            include: { skill: true },
            take: 5,
          },
        },
      },
      job: { select: { id: true, title: true } },
    },
    orderBy: { createdAt: 'desc' },
  });
}

export async function shortlistCandidate(
  userId: string,
  studentId: string,
  jobId?: string,
  notes?: string
) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  const existing = await prisma.shortlist.findFirst({
    where: {
      employerId: profile.id,
      studentId,
      jobId: jobId || null,
    },
  });
  if (existing) return existing;

  return prisma.shortlist.create({
    data: {
      employerId: profile.id,
      studentId,
      jobId: jobId || null,
      notes,
    },
    include: {
      student: {
        select: { id: true, fullName: true, trade: true },
      },
    },
  });
}

export async function getShortlist(userId: string) {
  const profile = await prisma.employerProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Employer profile not found');

  return prisma.shortlist.findMany({
    where: { employerId: profile.id },
    include: {
      student: {
        select: {
          id: true,
          fullName: true,
          trade: true,
          location: true,
          experienceYears: true,
          skills: {
            where: { isVerified: true },
            include: { skill: true },
            take: 4,
          },
        },
      },
      job: { select: { id: true, title: true } },
    },
    orderBy: { createdAt: 'desc' },
  });
}

export async function getSkillsCatalog(trade?: string) {
  return prisma.skill.findMany({
    where: {
      isActive: true,
      ...(trade ? { trade } : {}),
    },
    orderBy: [{ trade: 'asc' }, { name: 'asc' }],
  });
}
