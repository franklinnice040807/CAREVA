import { SubmissionStatus } from '@prisma/client';
import prisma from '../database/prisma.js';
import { getAIProvider, DEFAULT_RUBRIC, EvaluationResult } from './ai/index.js';

function generateCredentialId(): string {
  const year = new Date().getFullYear();
  const seq = Math.floor(100000 + Math.random() * 900000);
  return `CAREVA-VER-${year}-${seq}`;
}

export async function runEvaluation(userId: string, submissionId: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const submission = await prisma.skillSubmission.findFirst({
    where: { id: submissionId, studentId: profile.id },
    include: {
      skill: true,
      evaluations: true,
    },
  });

  if (!submission) throw new Error('Submission not found');
  if (submission.status === 'VERIFIED') {
    throw new Error('This submission is already verified');
  }

  // Mark under evaluation
  await prisma.skillSubmission.update({
    where: { id: submissionId },
    data: { status: SubmissionStatus.UNDER_EVALUATION },
  });

  // Get or create student skill link
  let studentSkill = await prisma.studentSkill.findUnique({
    where: {
      studentId_skillId: { studentId: profile.id, skillId: submission.skillId },
    },
  });
  if (!studentSkill) {
    studentSkill = await prisma.studentSkill.create({
      data: {
        studentId: profile.id,
        skillId: submission.skillId,
      },
    });
  }

  // Run AI provider
  const provider = getAIProvider();
  const result: EvaluationResult = await provider.evaluate(
    {
      skillName: submission.skill.name,
      skillCategory: submission.skill.category,
      skillTrade: submission.skill.trade,
      title: submission.title,
      description: submission.description,
      toolsUsed: submission.toolsUsed,
      steps: submission.steps,
      mediaType: submission.mediaType,
      selfAssessedLevel: studentSkill.selfAssessedLevel,
    },
    DEFAULT_RUBRIC
  );

  // Store evaluation
  const evaluation = await prisma.skillEvaluation.create({
    data: {
      submissionId: submission.id,
      studentSkillId: studentSkill.id,
      rubricScores: result.rubricScores,
      overallScore: result.overallScore,
      level: result.level,
      strengths: result.strengths,
      improvements: result.improvements,
      recommendations: result.recommendations,
      isDemo: result.isDemo,
    },
  });

  // Determine if verified (Job-ready or Intermediate with score >= 60 can be verified)
  const shouldVerify = result.overallScore >= 50;

  let credentialId: string | null = null;

  if (shouldVerify) {
    credentialId = studentSkill.credentialId || generateCredentialId();

    await prisma.studentSkill.update({
      where: { id: studentSkill.id },
      data: {
        isVerified: true,
        verifiedLevel: result.level,
        competencyScore: result.overallScore,
        verificationDate: new Date(),
        credentialId,
      },
    });

    // Upsert verification credential
    const existingCred = await prisma.verificationCredential.findUnique({
      where: { studentSkillId: studentSkill.id },
    });
    if (!existingCred) {
      await prisma.verificationCredential.create({
        data: {
          credentialId,
          studentSkillId: studentSkill.id,
          status: 'ACTIVE',
        },
      });
    }

    await prisma.skillSubmission.update({
      where: { id: submissionId },
      data: { status: SubmissionStatus.VERIFIED },
    });

    await prisma.notification.create({
      data: {
        userId,
        type: 'SKILL_VERIFIED',
        title: 'Skill verified!',
        message: `${submission.skill.name} is now CAREVA-verified at ${result.level.replace('_', '-')} level (${result.overallScore}%).`,
        link: '/student/passport',
      },
    });
  } else {
    await prisma.skillSubmission.update({
      where: { id: submissionId },
      data: { status: SubmissionStatus.NEEDS_IMPROVEMENT },
    });

    await prisma.notification.create({
      data: {
        userId,
        type: 'EVALUATION_COMPLETED',
        title: 'Evaluation complete — needs improvement',
        message: `Your demonstration for ${submission.skill.name} scored ${result.overallScore}%. Review feedback and re-submit.`,
        link: '/student/submissions',
      },
    });
  }

  await prisma.notification.create({
    data: {
      userId,
      type: 'EVALUATION_COMPLETED',
      title: 'AI evaluation completed',
      message: `CAREVA evaluation for "${submission.title}" is ready. Overall score: ${result.overallScore}%.`,
      link: '/student/submissions',
    },
  });

  return {
    evaluation,
    result,
    verified: shouldVerify,
    credentialId,
    skillName: submission.skill.name,
    submissionTitle: submission.title,
  };
}

export async function getEvaluationBySubmission(userId: string, submissionId: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const submission = await prisma.skillSubmission.findFirst({
    where: { id: submissionId, studentId: profile.id },
    include: {
      skill: true,
      evaluations: { orderBy: { evaluatedAt: 'desc' } },
    },
  });

  if (!submission) throw new Error('Submission not found');
  return submission;
}

export async function verifyCredentialPublic(credentialId: string) {
  const cred = await prisma.verificationCredential.findUnique({
    where: { credentialId },
    include: {
      studentSkill: {
        include: {
          skill: true,
          student: {
            select: {
              fullName: true,
              trade: true,
              institute: true,
              carevaId: true,
            },
          },
        },
      },
    },
  });

  if (!cred || cred.status !== 'ACTIVE') {
    return null;
  }

  const ss = cred.studentSkill;
  return {
    credentialId: cred.credentialId,
    issuedAt: cred.issuedAt,
    status: cred.status,
    studentName: ss.student.fullName,
    trade: ss.student.trade,
    institute: ss.student.institute,
    carevaId: ss.student.carevaId,
    skill: {
      name: ss.skill.name,
      category: ss.skill.category,
      trade: ss.skill.trade,
    },
    competencyLevel: ss.verifiedLevel,
    competencyScore: ss.competencyScore,
    verificationDate: ss.verificationDate,
    isVerified: ss.isVerified,
  };
}
