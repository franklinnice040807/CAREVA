import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { Role } from '@prisma/client';
import prisma from '../../database/prisma.js';

const JWT_SECRET = process.env.JWT_SECRET || process.env.SESSION_SECRET || 'careva-dev-secret-change-in-production';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

export interface TokenPayload {
  userId: string;
  email: string;
  role: Role;
}

export interface AuthUser {
  id: string;
  email: string;
  role: Role;
  fullName?: string;
  companyName?: string;
  profileCompletion?: number;
  carevaId?: string;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function signToken(payload: TokenPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN } as jwt.SignOptions);
}

export function verifyToken(token: string): TokenPayload {
  return jwt.verify(token, JWT_SECRET) as TokenPayload;
}

export async function registerUser(data: {
  email: string;
  password: string;
  role: 'STUDENT' | 'EMPLOYER';
  fullName?: string;
  companyName?: string;
}): Promise<{ user: AuthUser; token: string }> {
  const existing = await prisma.user.findUnique({ where: { email: data.email.toLowerCase() } });
  if (existing) {
    throw new Error('Email already registered');
  }

  if (data.role === 'STUDENT' && !data.fullName) {
    throw new Error('Full name is required for students');
  }
  if (data.role === 'EMPLOYER' && !data.companyName) {
    throw new Error('Company name is required for employers');
  }

  const passwordHash = await hashPassword(data.password);

  const user = await prisma.user.create({
    data: {
      email: data.email.toLowerCase(),
      passwordHash,
      role: data.role as Role,
      ...(data.role === 'STUDENT'
        ? {
            studentProfile: {
              create: {
                fullName: data.fullName!,
                profileCompletion: 15,
              },
            },
          }
        : {
            employerProfile: {
              create: {
                companyName: data.companyName!,
              },
            },
          }),
    },
    include: {
      studentProfile: true,
      employerProfile: true,
    },
  });

  const token = signToken({
    userId: user.id,
    email: user.email,
    role: user.role,
  });

  return {
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      fullName: user.studentProfile?.fullName,
      companyName: user.employerProfile?.companyName,
      profileCompletion: user.studentProfile?.profileCompletion,
      carevaId: user.studentProfile?.carevaId,
    },
    token,
  };
}

export async function loginUser(email: string, password: string): Promise<{ user: AuthUser; token: string }> {
  const user = await prisma.user.findUnique({
    where: { email: email.toLowerCase() },
    include: {
      studentProfile: true,
      employerProfile: true,
    },
  });

  if (!user || !user.isActive) {
    throw new Error('Invalid email or password');
  }

  const valid = await comparePassword(password, user.passwordHash);
  if (!valid) {
    throw new Error('Invalid email or password');
  }

  const token = signToken({
    userId: user.id,
    email: user.email,
    role: user.role,
  });

  return {
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      fullName: user.studentProfile?.fullName,
      companyName: user.employerProfile?.companyName,
      profileCompletion: user.studentProfile?.profileCompletion,
      carevaId: user.studentProfile?.carevaId,
    },
    token,
  };
}

export async function getUserById(userId: string): Promise<AuthUser | null> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      studentProfile: true,
      employerProfile: true,
    },
  });

  if (!user || !user.isActive) return null;

  return {
    id: user.id,
    email: user.email,
    role: user.role,
    fullName: user.studentProfile?.fullName,
    companyName: user.employerProfile?.companyName,
    profileCompletion: user.studentProfile?.profileCompletion,
    carevaId: user.studentProfile?.carevaId,
  };
}
