import { CompetencyLevel } from '@prisma/client';

export interface MatchingWeights {
  skillMatch: number;
  competencyMatch: number;
  experience: number;
  location: number;
  education: number;
}

export const DEFAULT_WEIGHTS: MatchingWeights = {
  skillMatch: 0.4,
  competencyMatch: 0.3,
  experience: 0.15,
  location: 0.1,
  education: 0.05,
};

export interface JobRequirementInput {
  skillId: string;
  skillName: string;
  requiredLevel: CompetencyLevel;
}

export interface CandidateSkillInput {
  skillId: string;
  skillName: string;
  verifiedLevel?: CompetencyLevel | null;
  competencyScore?: number | null;
  isVerified: boolean;
}

export interface CandidateInput {
  id: string;
  trade?: string | null;
  location?: string | null;
  experienceYears: number;
  institute?: string | null;
  course?: string | null;
  graduationYear?: number | null;
  skills: CandidateSkillInput[];
}

export interface JobInput {
  id: string;
  trade: string;
  location?: string | null;
  requiredCompetency: CompetencyLevel;
  experienceRequired: number;
  requirements: JobRequirementInput[];
}

export interface SkillGap {
  skillId: string;
  skillName: string;
  requiredLevel: CompetencyLevel;
  candidateLevel?: CompetencyLevel | null;
  candidateScore?: number | null;
  gapType: 'MISSING' | 'LEVEL_GAP';
  recommendation: string;
}

export interface MatchBreakdown {
  overallScore: number;
  skillMatch: number;
  competencyMatch: number;
  experienceMatch: number;
  locationMatch: number;
  educationMatch: number;
  skillGaps: SkillGap[];
  matchedSkills: Array<{ skillName: string; requiredLevel: string; candidateLevel: string; score: number }>;
}

const LEVEL_ORDER: Record<CompetencyLevel, number> = {
  BEGINNER: 1,
  INTERMEDIATE: 2,
  JOB_READY: 3,
};

const LEVEL_SCORE: Record<CompetencyLevel, number> = {
  BEGINNER: 40,
  INTERMEDIATE: 65,
  JOB_READY: 90,
};

function levelDistance(required: CompetencyLevel, actual?: CompetencyLevel | null): number {
  if (!actual) return 0;
  const diff = LEVEL_ORDER[actual] - LEVEL_ORDER[required];
  if (diff >= 0) return 100; // meets or exceeds
  if (diff === -1) return 55; // one level below
  return 25; // two levels below
}

function normalizeLocation(loc?: string | null): string {
  return (loc || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function locationSimilarity(jobLoc?: string | null, candLoc?: string | null): number {
  if (!jobLoc || !candLoc) return 50; // neutral if unknown
  const a = normalizeLocation(jobLoc);
  const b = normalizeLocation(candLoc);
  if (a === b) return 100;
  if (a.includes(b) || b.includes(a)) return 85;
  // city-level partial: compare first token
  const aCity = a.slice(0, 6);
  const bCity = b.slice(0, 6);
  if (aCity && bCity && (a.includes(bCity) || b.includes(aCity))) return 70;
  return 20;
}

function experienceScore(required: number, actual: number): number {
  if (required <= 0) return 100;
  if (actual >= required) return 100;
  if (actual >= required * 0.7) return 75;
  if (actual >= required * 0.4) return 50;
  if (actual > 0) return 30;
  return 10;
}

function educationScore(jobTrade: string, candidate: CandidateInput): number {
  let score = 50;
  if (candidate.trade && candidate.trade.toLowerCase() === jobTrade.toLowerCase()) score += 30;
  if (candidate.institute) score += 10;
  if (candidate.course) score += 5;
  if (candidate.graduationYear) score += 5;
  return Math.min(100, score);
}

/**
 * CAREVA Matching Engine
 * Calculates weighted match scores from verified skills, competency, experience, location, education.
 * Detects skill gaps with actionable recommendations.
 */
export class MatchingEngine {
  constructor(private weights: MatchingWeights = DEFAULT_WEIGHTS) {}

  calculate(job: JobInput, candidate: CandidateInput): MatchBreakdown {
    const verifiedSkills = candidate.skills.filter((s) => s.isVerified);
    const verifiedMap = new Map(verifiedSkills.map((s) => [s.skillId, s]));

    // --- Skill Match ---
    const requirements = job.requirements;
    let skillPoints = 0;
    const matchedSkills: MatchBreakdown['matchedSkills'] = [];
    const skillGaps: SkillGap[] = [];

    if (requirements.length === 0) {
      skillPoints = candidate.trade?.toLowerCase() === job.trade.toLowerCase() ? 70 : 40;
    } else {
      for (const req of requirements) {
        const candSkill = verifiedMap.get(req.skillId);
        if (candSkill) {
          const levelScore = levelDistance(req.requiredLevel, candSkill.verifiedLevel);
          const scoreComponent = candSkill.competencyScore != null
            ? (levelScore * 0.5 + Math.min(100, candSkill.competencyScore) * 0.5)
            : levelScore;
          skillPoints += scoreComponent;
          matchedSkills.push({
            skillName: req.skillName,
            requiredLevel: req.requiredLevel,
            candidateLevel: candSkill.verifiedLevel || 'BEGINNER',
            score: Math.round(scoreComponent),
          });

          // Level gap if candidate is below required
          if (
            candSkill.verifiedLevel &&
            LEVEL_ORDER[candSkill.verifiedLevel] < LEVEL_ORDER[req.requiredLevel]
          ) {
            skillGaps.push({
              skillId: req.skillId,
              skillName: req.skillName,
              requiredLevel: req.requiredLevel,
              candidateLevel: candSkill.verifiedLevel,
              candidateScore: candSkill.competencyScore,
              gapType: 'LEVEL_GAP',
              recommendation: `Advance from ${candSkill.verifiedLevel.replace('_', '-')} to ${req.requiredLevel.replace('_', '-')} in ${req.skillName}. Complete an advanced practical assessment.`,
            });
          }
        } else {
          skillPoints += 0;
          skillGaps.push({
            skillId: req.skillId,
            skillName: req.skillName,
            requiredLevel: req.requiredLevel,
            candidateLevel: null,
            candidateScore: null,
            gapType: 'MISSING',
            recommendation: `Acquire and verify ${req.skillName} at ${req.requiredLevel.replace('_', '-')} level through a CAREVA practical demonstration.`,
          });
        }
      }
      skillPoints = skillPoints / requirements.length;
    }

    // --- Competency Match (overall vs required) ---
    let competencyMatch = 50;
    if (verifiedSkills.length > 0) {
      const avgScore =
        verifiedSkills.reduce((sum, s) => sum + (s.competencyScore ?? LEVEL_SCORE[s.verifiedLevel || 'BEGINNER']), 0) /
        verifiedSkills.length;
      const requiredScore = LEVEL_SCORE[job.requiredCompetency];
      if (avgScore >= requiredScore) competencyMatch = 100;
      else if (avgScore >= requiredScore * 0.85) competencyMatch = 80;
      else if (avgScore >= requiredScore * 0.65) competencyMatch = 60;
      else competencyMatch = Math.round((avgScore / requiredScore) * 55);
    } else if (candidate.trade?.toLowerCase() === job.trade.toLowerCase()) {
      competencyMatch = 40;
    } else {
      competencyMatch = 20;
    }

    // --- Experience ---
    const experienceMatch = experienceScore(job.experienceRequired, candidate.experienceYears);

    // --- Location ---
    const locationMatch = locationSimilarity(job.location, candidate.location);

    // --- Education ---
    const educationMatch = educationScore(job.trade, candidate);

    // --- Weighted overall ---
    const w = this.weights;
    const overallScore = Math.round(
      skillPoints * w.skillMatch +
        competencyMatch * w.competencyMatch +
        experienceMatch * w.experience +
        locationMatch * w.location +
        educationMatch * w.education
    );

    return {
      overallScore: Math.max(0, Math.min(100, overallScore)),
      skillMatch: Math.round(skillPoints),
      competencyMatch: Math.round(competencyMatch),
      experienceMatch: Math.round(experienceMatch),
      locationMatch: Math.round(locationMatch),
      educationMatch: Math.round(educationMatch),
      skillGaps,
      matchedSkills,
    };
  }
}
