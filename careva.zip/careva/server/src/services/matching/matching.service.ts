import prisma from '../../database/prisma.js';
import { MatchingEngine, DEFAULT_WEIGHTS, MatchingWeights, CandidateInput, JobInput } from './MatchingEngine.js';

async function getWeights(): Promise<MatchingWeights> {
  try {
    const config = await prisma.platformConfig.findUnique({
      where: { key: 'matching_weights' },
    });
    if (config?.value && typeof config.value === 'object') {
      return { ...DEFAULT_WEIGHTS, ...(config.value as object) } as MatchingWeights;
    }
  } catch {
    // fall through
  }
  return DEFAULT_WEIGHTS;
}

function toCandidateInput(student: any): CandidateInput {
  return {
    id: student.id,
    trade: student.trade,
    location: student.location,
    experienceYears: student.experienceYears || 0,
    institute: student.institute,
    course: student.course,
    graduationYear: student.graduationYear,
    skills: (student.skills || []).map((s: any) => ({
      skillId: s.skillId,
      skillName: s.skill?.name || '',
      verifiedLevel: s.verifiedLevel,
      competencyScore: s.competencyScore,
      isVerified: s.isVerified,
    })),
  };
}

function toJobInput(job: any): JobInput {
  return {
    id: job.id,
    trade: job.trade,
    location: job.location,
    requiredCompetency: job.requiredCompetency,
    experienceRequired: job.experienceRequired || 0,
    requirements: (job.requirements || []).map((r: any) => ({
      skillId: r.skillId,
      skillName: r.skill?.name || '',
      requiredLevel: r.requiredLevel,
    })),
  };
}

export async function matchJobToCandidates(jobId: string, limit = 20) {
  const job = await prisma.job.findUnique({
    where: { id: jobId },
    include: {
      requirements: { include: { skill: true } },
    },
  });
  if (!job || !job.isActive) throw new Error('Job not found or inactive');

  const students = await prisma.studentProfile.findMany({
    include: {
      skills: {
        where: { isVerified: true },
        include: { skill: true },
      },
    },
  });

  const engine = new MatchingEngine(await getWeights());
  const jobInput = toJobInput(job);
  const results = [];

  for (const student of students) {
    const breakdown = engine.calculate(jobInput, toCandidateInput(student));
    results.push({ student, breakdown });

    // Upsert JobMatch
    await prisma.jobMatch.upsert({
      where: {
        jobId_studentId: { jobId: job.id, studentId: student.id },
      },
      create: {
        jobId: job.id,
        studentId: student.id,
        overallScore: breakdown.overallScore,
        skillMatch: breakdown.skillMatch,
        competencyMatch: breakdown.competencyMatch,
        experienceMatch: breakdown.experienceMatch,
        locationMatch: breakdown.locationMatch,
        educationMatch: breakdown.educationMatch,
        skillGaps: breakdown.skillGaps as any,
      },
      update: {
        overallScore: breakdown.overallScore,
        skillMatch: breakdown.skillMatch,
        competencyMatch: breakdown.competencyMatch,
        experienceMatch: breakdown.experienceMatch,
        locationMatch: breakdown.locationMatch,
        educationMatch: breakdown.educationMatch,
        skillGaps: breakdown.skillGaps as any,
        calculatedAt: new Date(),
      },
    });
  }

  results.sort((a, b) => b.breakdown.overallScore - a.breakdown.overallScore);
  return results.slice(0, limit).map((r) => ({
    studentId: r.student.id,
    fullName: r.student.fullName,
    trade: r.student.trade,
    location: r.student.location,
    experienceYears: r.student.experienceYears,
    carevaId: r.student.carevaId,
    skills: r.student.skills,
    ...r.breakdown,
  }));
}

export async function matchStudentToJobs(userId: string, limit = 20) {
  const profile = await prisma.studentProfile.findUnique({
    where: { userId },
    include: {
      skills: {
        where: { isVerified: true },
        include: { skill: true },
      },
    },
  });
  if (!profile) throw new Error('Student profile not found');

  const jobs = await prisma.job.findMany({
    where: { isActive: true },
    include: {
      requirements: { include: { skill: true } },
      employer: { select: { companyName: true, location: true } },
    },
  });

  const engine = new MatchingEngine(await getWeights());
  const candidate = toCandidateInput(profile);
  const results = [];

  for (const job of jobs) {
    const breakdown = engine.calculate(toJobInput(job), candidate);
    results.push({ job, breakdown });

    await prisma.jobMatch.upsert({
      where: {
        jobId_studentId: { jobId: job.id, studentId: profile.id },
      },
      create: {
        jobId: job.id,
        studentId: profile.id,
        overallScore: breakdown.overallScore,
        skillMatch: breakdown.skillMatch,
        competencyMatch: breakdown.competencyMatch,
        experienceMatch: breakdown.experienceMatch,
        locationMatch: breakdown.locationMatch,
        educationMatch: breakdown.educationMatch,
        skillGaps: breakdown.skillGaps as any,
      },
      update: {
        overallScore: breakdown.overallScore,
        skillMatch: breakdown.skillMatch,
        competencyMatch: breakdown.competencyMatch,
        experienceMatch: breakdown.experienceMatch,
        locationMatch: breakdown.locationMatch,
        educationMatch: breakdown.educationMatch,
        skillGaps: breakdown.skillGaps as any,
        calculatedAt: new Date(),
      },
    });
  }

  results.sort((a, b) => b.breakdown.overallScore - a.breakdown.overallScore);
  return results.slice(0, limit).map((r) => ({
    jobId: r.job.id,
    title: r.job.title,
    trade: r.job.trade,
    location: r.job.location,
    salaryRange: r.job.salaryRange,
    employmentType: r.job.employmentType,
    requiredCompetency: r.job.requiredCompetency,
    companyName: r.job.employer.companyName,
    requirements: r.job.requirements,
    ...r.breakdown,
  }));
}

export async function getMatchDetail(jobId: string, studentId: string) {
  const match = await prisma.jobMatch.findUnique({
    where: { jobId_studentId: { jobId, studentId } },
    include: {
      job: {
        include: {
          requirements: { include: { skill: true } },
          employer: { select: { companyName: true } },
        },
      },
      student: {
        include: {
          skills: {
            where: { isVerified: true },
            include: { skill: true },
          },
        },
      },
    },
  });

  if (match) return match;

  // Calculate on the fly if not stored
  const job = await prisma.job.findUnique({
    where: { id: jobId },
    include: { requirements: { include: { skill: true } }, employer: true },
  });
  const student = await prisma.studentProfile.findUnique({
    where: { id: studentId },
    include: {
      skills: { where: { isVerified: true }, include: { skill: true } },
    },
  });
  if (!job || !student) throw new Error('Job or student not found');

  const engine = new MatchingEngine(await getWeights());
  const breakdown = engine.calculate(toJobInput(job), toCandidateInput(student));
  return {
    jobId,
    studentId,
    ...breakdown,
    job,
    student,
  };
}

export async function applyToJob(userId: string, jobId: string, coverNote?: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  const job = await prisma.job.findFirst({
    where: { id: jobId, isActive: true },
    include: { employer: true },
  });
  if (!job) throw new Error('Job not found or inactive');

  const existing = await prisma.application.findUnique({
    where: { jobId_studentId: { jobId, studentId: profile.id } },
  });
  if (existing) throw new Error('Already applied to this job');

  const application = await prisma.application.create({
    data: {
      jobId,
      studentId: profile.id,
      coverNote,
      status: 'APPLIED',
    },
    include: {
      job: { select: { title: true } },
    },
  });

  // Notify employer
  const employerUser = await prisma.employerProfile.findUnique({
    where: { id: job.employerId },
    select: { userId: true },
  });
  if (employerUser) {
    await prisma.notification.create({
      data: {
        userId: employerUser.userId,
        type: 'NEW_APPLICATION',
        title: 'New application received',
        message: `${profile.fullName} applied for "${job.title}".`,
        link: '/employer/applications',
      },
    });
  }

  await prisma.notification.create({
    data: {
      userId,
      type: 'APPLICATION_UPDATE',
      title: 'Application submitted',
      message: `You applied for "${job.title}".`,
      link: '/student/jobs',
    },
  });

  return application;
}

export async function getStudentApplications(userId: string) {
  const profile = await prisma.studentProfile.findUnique({ where: { userId } });
  if (!profile) throw new Error('Student profile not found');

  return prisma.application.findMany({
    where: { studentId: profile.id },
    include: {
      job: {
        include: {
          employer: { select: { companyName: true, location: true } },
          requirements: { include: { skill: true } },
        },
      },
    },
    orderBy: { createdAt: 'desc' },
  });
}

export async function generateCareerInsights(userId: string) {
  const profile = await prisma.studentProfile.findUnique({
    where: { userId },
    include: {
      skills: {
        where: { isVerified: true },
        include: { skill: true },
      },
      jobMatches: {
        orderBy: { overallScore: 'desc' },
        take: 10,
        include: {
          job: {
            include: {
              employer: { select: { companyName: true } },
              requirements: { include: { skill: true } },
            },
          },
        },
      },
    },
  });
  if (!profile) throw new Error('Student profile not found');

  // Collect skill gaps from top matches
  const gapMap = new Map<string, any>();
  for (const m of profile.jobMatches) {
    const gaps = (m.skillGaps as any[]) || [];
    for (const g of gaps) {
      if (!gapMap.has(g.skillId)) {
        gapMap.set(g.skillId, g);
      }
    }
  }

  const skillGaps = Array.from(gapMap.values());

  // Recommended skills to acquire
  const recommendedSkills = skillGaps.slice(0, 5).map((g) => ({
    skillName: g.skillName,
    reason: g.recommendation,
    gapType: g.gapType,
    requiredLevel: g.requiredLevel,
  }));

  // Career pathway based on trade
  const pathways: Record<string, string[]> = {
    Electrical: [
      'Electrical Technician',
      'Industrial Electrical Technician',
      'Automation Technician',
      'Industrial Automation Specialist',
    ],
    Welding: [
      'Welder',
      'Structural Welder',
      'Welding Inspector',
      'Welding Supervisor',
    ],
    Mechanical: [
      'Fitter',
      'Mechanical Technician',
      'CNC Operator',
      'Maintenance Specialist',
    ],
    Electronics: [
      'Electronics Technician',
      'PCB Technician',
      'Industrial Electronics Technician',
      'Embedded Systems Technician',
    ],
    Automobile: [
      'Auto Mechanic',
      'Service Technician',
      'Diagnostics Specialist',
      'Service Advisor',
    ],
  };

  const pathway = pathways[profile.trade || ''] || [
    'Junior Technician',
    'Technician',
    'Senior Technician',
    'Specialist / Supervisor',
  ];

  // Improvement recommendations
  const improvements: string[] = [];
  if (profile.skills.length === 0) {
    improvements.push('Add skills and submit practical demonstrations to earn CAREVA verification.');
  } else if (profile.skills.filter((s) => s.isVerified).length < 2) {
    improvements.push('Verify more skills to improve job match scores.');
  }
  if (skillGaps.length > 0) {
    improvements.push(`Close skill gaps: ${skillGaps.slice(0, 2).map((g) => g.skillName).join(', ')}.`);
  }
  if (!profile.location) {
    improvements.push('Add your location to improve location-based matching.');
  }
  if (profile.experienceYears < 1) {
    improvements.push('Build practical experience through projects and internships.');
  }

  // Persist recommendations
  await prisma.careerRecommendation.deleteMany({
    where: { studentId: profile.id },
  });

  const recs = [];
  for (const sk of recommendedSkills) {
    recs.push(
      await prisma.careerRecommendation.create({
        data: {
          studentId: profile.id,
          type: 'SKILL_GAP',
          title: `Learn ${sk.skillName}`,
          content: sk.reason,
          priority: 10,
        },
      })
    );
  }
  for (const imp of improvements) {
    recs.push(
      await prisma.careerRecommendation.create({
        data: {
          studentId: profile.id,
          type: 'IMPROVEMENT',
          title: 'Recommendation',
          content: imp,
          priority: 5,
        },
      })
    );
  }

  return {
    recommendedJobs: profile.jobMatches.slice(0, 5).map((m) => ({
      jobId: m.jobId,
      title: m.job.title,
      companyName: m.job.employer.companyName,
      overallScore: m.overallScore,
      skillGaps: m.skillGaps,
    })),
    recommendedSkills,
    skillGaps,
    careerPathway: pathway,
    currentRole: pathway[0],
    targetRole: pathway[pathway.length - 1],
    improvements,
    recommendations: recs,
  };
}
