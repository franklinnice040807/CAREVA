import { Request, Response, NextFunction } from 'express';
import { Role } from '@prisma/client';
import { verifyToken, getUserById, AuthUser } from '../services/auth/auth.service.js';

export interface AuthRequest extends Request {
  user?: AuthUser;
  tokenPayload?: {
    userId: string;
    email: string;
    role: Role;
  };
}

export async function authenticate(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (!token) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }

    const payload = verifyToken(token);
    const user = await getUserById(payload.userId);

    if (!user) {
      return res.status(401).json({ success: false, message: 'User not found or inactive' });
    }

    req.user = user;
    req.tokenPayload = payload;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
}

export function authorize(...roles: Role[]) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Insufficient permissions' });
    }
    next();
  };
}

export function optionalAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return next();
  }

  try {
    const payload = verifyToken(token);
    getUserById(payload.userId)
      .then((user) => {
        if (user) {
          req.user = user;
          req.tokenPayload = payload;
        }
        next();
      })
      .catch(() => next());
  } catch {
    next();
  }
}
