import { PrismaClient, Role, CompetencyLevel, SubmissionStatus, ApplicationStatus, EmploymentType } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

function credId(n: number) {
  return `CAREVA-VER-2026-${String(100000 + n).padStart(6, '0')}`;
}

async function main() {
  console.log('🌱 Seeding CAREVA database (competition demo data)...\n');

  await prisma.notification.deleteMany();
  await prisma.careerRecommendation.deleteMany();
  await prisma.employerFeedback.deleteMany();
  await prisma.shortlist.deleteMany();
  await prisma.application.deleteMany();
  await prisma.jobMatch.deleteMany();
  await prisma.jobRequirement.deleteMany();
  await prisma.job.deleteMany();
  await prisma.verificationCredential.deleteMany();
  await prisma.skillEvaluation.deleteMany();
  await prisma.skillSubmission.deleteMany();
  await prisma.studentSkill.deleteMany();
  await prisma.certificate.deleteMany();
  await prisma.project.deleteMany();
  await prisma.skill.deleteMany();
  await prisma.studentProfile.deleteMany();
  await prisma.employerProfile.deleteMany();
  await prisma.user.deleteMany();
  await prisma.platformConfig.deleteMany();

  const passwordHash = await bcrypt.hash('Demo@123', 12);

  // Admin
  await prisma.user.create({
    data: { email: 'admin@careva.app', passwordHash, role: Role.ADMIN },
  });
  console.log('✓ Admin: admin@careva.app');

  // Skills catalog
  const skillsData = [
    { name: 'Industrial Wiring', category: 'Electrical Installation', trade: 'Electrical' },
    { name: 'PLC Programming', category: 'Automation', trade: 'Electrical' },
    { name: 'Motor Control', category: 'Electrical Machines', trade: 'Electrical' },
    { name: 'Panel Assembly', category: 'Electrical Installation', trade: 'Electrical' },
    { name: 'MIG Welding', category: 'Welding Processes', trade: 'Welding' },
    { name: 'TIG Welding', category: 'Welding Processes', trade: 'Welding' },
    { name: 'Arc Welding', category: 'Welding Processes', trade: 'Welding' },
    { name: 'Weld Inspection', category: 'Quality', trade: 'Welding' },
    { name: 'Precision Fitting', category: 'Fitting', trade: 'Mechanical' },
    { name: 'Assembly & Alignment', category: 'Fitting', trade: 'Mechanical' },
    { name: 'Basic CNC Operation', category: 'Machining', trade: 'Mechanical' },
    { name: 'Circuit Testing', category: 'Electronics', trade: 'Electronics' },
    { name: 'PCB Assembly', category: 'Electronics', trade: 'Electronics' },
    { name: 'Engine Diagnostics', category: 'Automobile', trade: 'Automobile' },
    { name: 'Vehicle Electrical Systems', category: 'Automobile', trade: 'Automobile' },
  ];

  const skills: Record<string, { id: string; name: string; trade: string }> = {};
  for (const sk of skillsData) {
    const s = await prisma.skill.create({
      data: { name: sk.name, category: sk.category, trade: sk.trade, description: `${sk.name} competency for ${sk.trade}.` },
    });
    skills[sk.name] = s;
  }
  console.log(`✓ ${skillsData.length} skills`);

  // Students
  const studentsMeta = [
    {
      email: 'rahul.electrical@careva.demo',
      fullName: 'Rahul Sharma',
      trade: 'Electrical',
      institute: 'Government Industrial Training Institute, Pune',
      course: 'Electrician (2 Year)',
      graduationYear: 2025,
      location: 'Pune, Maharashtra',
      phone: '+91 98765 43210',
      about: 'Passionate about industrial electrical systems and automation. Strong in PLC and motor control.',
      experienceYears: 1.5,
      profileCompletion: 88,
    },
    {
      email: 'priya.welding@careva.demo',
      fullName: 'Priya Patel',
      trade: 'Welding',
      institute: 'Advanced Vocational Training Center, Ahmedabad',
      course: 'Welder (Structural)',
      graduationYear: 2024,
      location: 'Ahmedabad, Gujarat',
      phone: '+91 98234 56789',
      about: 'Skilled in MIG, TIG and arc welding. Strong focus on safety and quality standards.',
      experienceYears: 2,
      profileCompletion: 92,
    },
    {
      email: 'amit.mechanical@careva.demo',
      fullName: 'Amit Kumar',
      trade: 'Mechanical',
      institute: 'Industrial Training Institute, Delhi',
      course: 'Fitter',
      graduationYear: 2025,
      location: 'Delhi NCR',
      phone: '+91 99112 33445',
      about: 'Hands-on experience with precision fitting, assembly and basic CNC operations.',
      experienceYears: 1,
      profileCompletion: 75,
    },
    {
      email: 'sneha.electronics@careva.demo',
      fullName: 'Sneha Reddy',
      trade: 'Electronics',
      institute: 'Polytechnic College, Hyderabad',
      course: 'Electronics Technician',
      graduationYear: 2024,
      location: 'Hyderabad, Telangana',
      phone: '+91 98450 11223',
      about: 'Circuit design, PCB assembly and testing. Interested in industrial electronics and IoT.',
      experienceYears: 1.5,
      profileCompletion: 80,
    },
    {
      email: 'vikram.auto@careva.demo',
      fullName: 'Vikram Singh',
      trade: 'Automobile',
      institute: 'Automotive Training Institute, Chennai',
      course: 'Auto Mechanic',
      graduationYear: 2025,
      location: 'Chennai, Tamil Nadu',
      phone: '+91 97890 55667',
      about: 'Engine diagnostics, servicing and electrical systems of modern vehicles.',
      experienceYears: 0.5,
      profileCompletion: 70,
    },
  ];

  const students: any[] = [];
  for (const s of studentsMeta) {
    const user = await prisma.user.create({
      data: {
        email: s.email,
        passwordHash,
        role: Role.STUDENT,
        studentProfile: {
          create: {
            fullName: s.fullName,
            trade: s.trade,
            institute: s.institute,
            course: s.course,
            graduationYear: s.graduationYear,
            location: s.location,
            phone: s.phone,
            about: s.about,
            experienceYears: s.experienceYears,
            profileCompletion: s.profileCompletion,
          },
        },
      },
      include: { studentProfile: true },
    });
    students.push(user);
    console.log(`✓ Student: ${s.fullName}`);
  }

  const rahul = students[0].studentProfile!;
  const priya = students[1].studentProfile!;
  const amit = students[2].studentProfile!;
  const sneha = students[3].studentProfile!;
  const vikram = students[4].studentProfile!;

  // Verified skills for Rahul (Electrical)
  const rahulSkills = [
    { skill: 'Industrial Wiring', level: CompetencyLevel.JOB_READY, score: 86, n: 1 },
    { skill: 'PLC Programming', level: CompetencyLevel.INTERMEDIATE, score: 68, n: 2 },
    { skill: 'Motor Control', level: CompetencyLevel.JOB_READY, score: 82, n: 3 },
  ];
  for (const rs of rahulSkills) {
    const ss = await prisma.studentSkill.create({
      data: {
        studentId: rahul.id,
        skillId: skills[rs.skill].id,
        selfAssessedLevel: rs.level,
        verifiedLevel: rs.level,
        competencyScore: rs.score,
        isVerified: true,
        verificationDate: new Date(),
        credentialId: credId(rs.n),
      },
    });
    await prisma.verificationCredential.create({
      data: { credentialId: credId(rs.n), studentSkillId: ss.id, status: 'ACTIVE' },
    });
    const sub = await prisma.skillSubmission.create({
      data: {
        studentId: rahul.id,
        skillId: skills[rs.skill].id,
        title: `${rs.skill} practical demonstration`,
        description: `Demonstrated ${rs.skill} with proper safety, tool handling, process execution and quality checks. Used standard industrial equipment and followed workplace procedures.`,
        toolsUsed: 'Multimeter, PPE, industrial tools, measuring instruments',
        steps: '1. Safety briefing and PPE\n2. Tool setup and inspection\n3. Process execution\n4. Quality and accuracy check\n5. Cleanup and documentation',
        mediaType: 'video',
        status: SubmissionStatus.VERIFIED,
      },
    });
    await prisma.skillEvaluation.create({
      data: {
        submissionId: sub.id,
        studentSkillId: ss.id,
        rubricScores: {
          toolHandling: rs.score - 2,
          safety: Math.min(95, rs.score + 5),
          processExecution: rs.score - 4,
          accuracy: rs.score,
          quality: rs.score - 1,
          completion: rs.score + 1,
          workplaceReadiness: rs.score - 3,
        },
        overallScore: rs.score,
        level: rs.level,
        strengths: [`Strong ${rs.skill} execution`, 'Good safety awareness'],
        improvements: ['Document steps more clearly', 'Improve consistency under time pressure'],
        recommendations: ['Maintain standards', 'Consider advanced assessments'],
        isDemo: true,
      },
    });
  }

  // Priya welding skills
  const priyaSkills = [
    { skill: 'MIG Welding', level: CompetencyLevel.JOB_READY, score: 89, n: 4 },
    { skill: 'TIG Welding', level: CompetencyLevel.JOB_READY, score: 84, n: 5 },
    { skill: 'Arc Welding', level: CompetencyLevel.INTERMEDIATE, score: 72, n: 6 },
  ];
  for (const ps of priyaSkills) {
    const ss = await prisma.studentSkill.create({
      data: {
        studentId: priya.id,
        skillId: skills[ps.skill].id,
        selfAssessedLevel: ps.level,
        verifiedLevel: ps.level,
        competencyScore: ps.score,
        isVerified: true,
        verificationDate: new Date(),
        credentialId: credId(ps.n),
      },
    });
    await prisma.verificationCredential.create({
      data: { credentialId: credId(ps.n), studentSkillId: ss.id, status: 'ACTIVE' },
    });
  }

  // Amit mechanical
  const amitSkill = await prisma.studentSkill.create({
    data: {
      studentId: amit.id,
      skillId: skills['Precision Fitting'].id,
      selfAssessedLevel: CompetencyLevel.INTERMEDIATE,
      verifiedLevel: CompetencyLevel.INTERMEDIATE,
      competencyScore: 71,
      isVerified: true,
      verificationDate: new Date(),
      credentialId: credId(7),
    },
  });
  await prisma.verificationCredential.create({
    data: { credentialId: credId(7), studentSkillId: amitSkill.id, status: 'ACTIVE' },
  });

  // Sneha electronics
  await prisma.studentSkill.create({
    data: {
      studentId: sneha.id,
      skillId: skills['PCB Assembly'].id,
      selfAssessedLevel: CompetencyLevel.JOB_READY,
      verifiedLevel: CompetencyLevel.JOB_READY,
      competencyScore: 88,
      isVerified: true,
      verificationDate: new Date(),
      credentialId: credId(8),
    },
  }).then(async (ss) => {
    await prisma.verificationCredential.create({
      data: { credentialId: credId(8), studentSkillId: ss.id, status: 'ACTIVE' },
    });
  });

  // Certificates & projects
  await prisma.certificate.create({
    data: { studentId: rahul.id, title: 'ITI Electrician Certificate', issuer: 'NCVT', issueDate: new Date('2025-01-15') },
  });
  await prisma.project.create({
    data: {
      studentId: rahul.id,
      title: 'Industrial Panel Wiring Project',
      description: 'Wired and tested a 3-phase control panel with PLC interface.',
      skillsUsed: ['Industrial Wiring', 'PLC Programming', 'Motor Control'],
    },
  });
  await prisma.project.create({
    data: {
      studentId: priya.id,
      title: 'Structural Steel Frame Welding',
      description: 'Completed MIG welding of structural frame with inspection pass.',
      skillsUsed: ['MIG Welding', 'Weld Inspection'],
    },
  });

  console.log('✓ Verified skills, submissions, certificates, projects');

  // Employers
  const employersMeta = [
    {
      email: 'hr@precisioneng.in',
      companyName: 'Precision Engineering Works',
      industry: 'Manufacturing',
      location: 'Pune, Maharashtra',
      website: 'https://precisioneng.example.in',
      description: 'Industrial electrical panels and automation solutions. We hire skilled vocational talent.',
      companySize: '51-200',
      contactInfo: 'hr@precisioneng.in | +91 20 1234 5678',
    },
    {
      email: 'careers@steelcraft.in',
      companyName: 'SteelCraft Fabricators',
      industry: 'Fabrication & Welding',
      location: 'Ahmedabad, Gujarat',
      website: 'https://steelcraft.example.in',
      description: 'Structural steel fabrication and welding specialists.',
      companySize: '11-50',
      contactInfo: 'careers@steelcraft.in',
    },
    {
      email: 'jobs@autotech.in',
      companyName: 'AutoTech Service Centers',
      industry: 'Automobile',
      location: 'Chennai, Tamil Nadu',
      website: 'https://autotech.example.in',
      description: 'Multi-brand automobile service network.',
      companySize: '201-500',
      contactInfo: 'jobs@autotech.in',
    },
  ];

  const employers: any[] = [];
  for (const e of employersMeta) {
    const user = await prisma.user.create({
      data: {
        email: e.email,
        passwordHash,
        role: Role.EMPLOYER,
        employerProfile: {
          create: {
            companyName: e.companyName,
            industry: e.industry,
            location: e.location,
            website: e.website,
            description: e.description,
            companySize: e.companySize,
            contactInfo: e.contactInfo,
          },
        },
      },
      include: { employerProfile: true },
    });
    employers.push(user);
    console.log(`✓ Employer: ${e.companyName}`);
  }

  const precision = employers[0].employerProfile!;
  const steelcraft = employers[1].employerProfile!;
  const autotech = employers[2].employerProfile!;

  // Jobs
  const job1 = await prisma.job.create({
    data: {
      employerId: precision.id,
      title: 'Industrial Electrician',
      description: 'Looking for job-ready electricians with industrial wiring and motor control experience. PLC knowledge is a plus. Safety-first culture.',
      trade: 'Electrical',
      location: 'Pune, Maharashtra',
      salaryRange: '₹18,000–28,000',
      employmentType: EmploymentType.FULL_TIME,
      requiredCompetency: CompetencyLevel.JOB_READY,
      experienceRequired: 1,
      requirements: {
        create: [
          { skillId: skills['Industrial Wiring'].id, requiredLevel: CompetencyLevel.JOB_READY },
          { skillId: skills['Motor Control'].id, requiredLevel: CompetencyLevel.INTERMEDIATE },
          { skillId: skills['PLC Programming'].id, requiredLevel: CompetencyLevel.INTERMEDIATE },
        ],
      },
    },
    include: { requirements: true },
  });

  const job2 = await prisma.job.create({
    data: {
      employerId: steelcraft.id,
      title: 'Structural Welder (MIG/TIG)',
      description: 'Hire welders with verified MIG and TIG competency for structural fabrication projects.',
      trade: 'Welding',
      location: 'Ahmedabad, Gujarat',
      salaryRange: '₹16,000–25,000',
      employmentType: EmploymentType.FULL_TIME,
      requiredCompetency: CompetencyLevel.JOB_READY,
      experienceRequired: 1.5,
      requirements: {
        create: [
          { skillId: skills['MIG Welding'].id, requiredLevel: CompetencyLevel.JOB_READY },
          { skillId: skills['TIG Welding'].id, requiredLevel: CompetencyLevel.INTERMEDIATE },
        ],
      },
    },
  });

  const job3 = await prisma.job.create({
    data: {
      employerId: autotech.id,
      title: 'Auto Service Technician',
      description: 'Entry-level technician for multi-brand service center. Diagnostics experience preferred.',
      trade: 'Automobile',
      location: 'Chennai, Tamil Nadu',
      salaryRange: '₹12,000–18,000',
      employmentType: EmploymentType.FULL_TIME,
      requiredCompetency: CompetencyLevel.INTERMEDIATE,
      experienceRequired: 0.5,
      requirements: {
        create: [
          { skillId: skills['Engine Diagnostics'].id, requiredLevel: CompetencyLevel.INTERMEDIATE },
          { skillId: skills['Vehicle Electrical Systems'].id, requiredLevel: CompetencyLevel.BEGINNER },
        ],
      },
    },
  });

  console.log('✓ 3 jobs with requirements');

  // Job matches (pre-computed for demo)
  await prisma.jobMatch.create({
    data: {
      jobId: job1.id,
      studentId: rahul.id,
      overallScore: 91,
      skillMatch: 95,
      competencyMatch: 90,
      experienceMatch: 100,
      locationMatch: 100,
      educationMatch: 95,
      skillGaps: [],
    },
  });
  await prisma.jobMatch.create({
    data: {
      jobId: job2.id,
      studentId: priya.id,
      overallScore: 94,
      skillMatch: 98,
      competencyMatch: 95,
      experienceMatch: 100,
      locationMatch: 100,
      educationMatch: 90,
      skillGaps: [],
    },
  });
  // Rahul has gap on welding job
  await prisma.jobMatch.create({
    data: {
      jobId: job2.id,
      studentId: rahul.id,
      overallScore: 28,
      skillMatch: 5,
      competencyMatch: 40,
      experienceMatch: 50,
      locationMatch: 20,
      educationMatch: 40,
      skillGaps: [
        {
          skillId: skills['MIG Welding'].id,
          skillName: 'MIG Welding',
          requiredLevel: 'JOB_READY',
          gapType: 'MISSING',
          recommendation: 'Acquire and verify MIG Welding at Job-ready level through a CAREVA practical demonstration.',
        },
      ],
    },
  });

  // Applications
  const app1 = await prisma.application.create({
    data: {
      jobId: job1.id,
      studentId: rahul.id,
      status: ApplicationStatus.SHORTLISTED,
      coverNote: 'I have verified Industrial Wiring and Motor Control skills via CAREVA.',
    },
  });
  await prisma.application.create({
    data: {
      jobId: job2.id,
      studentId: priya.id,
      status: ApplicationStatus.APPLIED,
    },
  });
  const appHired = await prisma.application.create({
    data: {
      jobId: job1.id,
      studentId: sneha.id,
      status: ApplicationStatus.HIRED,
    },
  });

  // Shortlist
  await prisma.shortlist.create({
    data: { employerId: precision.id, studentId: rahul.id, jobId: job1.id, notes: 'Strong electrical verified skills' },
  });

  // Sample feedback on hire
  await prisma.employerFeedback.create({
    data: {
      applicationId: appHired.id,
      studentId: sneha.id,
      practicalScore: 4,
      technicalScore: 4,
      safetyScore: 5,
      reliabilityScore: 4,
      communicationScore: 3,
      workplaceScore: 4,
      writtenFeedback: 'Good practical skills and safety awareness. Communication can improve with team briefings.',
    },
  });

  // Notifications
  await prisma.notification.createMany({
    data: [
      {
        userId: students[0].id,
        type: 'SKILL_VERIFIED',
        title: 'Skill verified!',
        message: 'Industrial Wiring is now CAREVA-verified at Job-ready level (86%).',
        link: '/student/passport',
      },
      {
        userId: students[0].id,
        type: 'NEW_JOB_MATCH',
        title: 'New job match',
        message: 'Industrial Electrician at Precision Engineering Works — 91% match.',
        link: '/student/jobs',
      },
      {
        userId: students[0].id,
        type: 'APPLICATION_UPDATE',
        title: 'Application shortlisted',
        message: 'Your application for Industrial Electrician is now: SHORTLISTED.',
        link: '/student/jobs',
      },
      {
        userId: employers[0].id,
        type: 'NEW_APPLICATION',
        title: 'New application received',
        message: 'Rahul Sharma applied for "Industrial Electrician".',
        link: '/employer/applications',
      },
      {
        userId: students[3].id,
        type: 'EMPLOYER_FEEDBACK',
        title: 'Employer feedback received',
        message: 'You received performance feedback for your role at the hiring company.',
        link: '/student/passport',
      },
    ],
  });

  // Platform config
  await prisma.platformConfig.create({
    data: {
      key: 'matching_weights',
      value: { skillMatch: 0.4, competencyMatch: 0.3, experience: 0.15, location: 0.1, education: 0.05 },
    },
  });
  await prisma.platformConfig.create({
    data: {
      key: 'competency_thresholds',
      value: { beginner: { min: 0, max: 49 }, intermediate: { min: 50, max: 74 }, jobReady: { min: 75, max: 100 } },
    },
  });

  console.log('\n✅ Competition demo seed completed!');
  console.log('\n📋 Demo Accounts (password: Demo@123)');
  console.log('   Admin:    admin@careva.app');
  console.log('   Student:  rahul.electrical@careva.demo  ← best for full demo');
  console.log('   Student:  priya.welding@careva.demo');
  console.log('   Employer: hr@precisioneng.in           ← best for employer demo');
  console.log('   Employer: careers@steelcraft.in');
  console.log('\n🔑 Sample credential: CAREVA-VER-2026-100001');
  console.log('   Public verify: /verify/CAREVA-VER-2026-100001\n');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
